package com.example.eflier_patron;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONArray;
import org.json.JSONObject;

import com.example.models.Account;
import com.example.models.Eflier;
import com.example.models.Server;
import com.example.models.Style;
import com.squareup.picasso.Picasso;

import android.app.Activity;
import android.app.ProgressDialog;
import android.graphics.Typeface;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

@SuppressWarnings({"deprecation", "resource"})
public class ViewActivity extends Activity {

	private Server myServer = new Server();
	private Account myAccount = null;
	private LinearLayout LayoutPanel;
	private int eflier_id = 0;
	private boolean isExisting = false;
	
	@Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view);
        
        /* INSTANTIATE OBJECTS */
        LayoutPanel = (LinearLayout) findViewById(R.id.ve_layout_panel);
        
        /* SET ACCOUNT INFO */
        int account_id = getIntent().getExtras().getInt("account_id");
        eflier_id = getIntent().getExtras().getInt("eflier_id");
        myAccount = new Account(account_id, null, null);
        new FetchAccount().execute(String.valueOf(account_id), "FETCH_ACCOUNT");
	}
	
	private class FetchAccount extends AsyncTask<String, String, String> {
			
		@Override protected String doInBackground(String... params) {
			
			List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>();
			String[] POST_VALUES = { "account_id", "function" };
        	for(int x = 0; x < params.length; x++) { nameValuePairs.add(new BasicNameValuePair(POST_VALUES[x], params[x])); }
			
			try {
				
				HttpClient httpClient = new DefaultHttpClient();
				HttpPost httpPost = new HttpPost("http://" + myServer.localhost() + "/eflier/api/account_api.php");
				httpPost.setEntity(new UrlEncodedFormEntity(nameValuePairs));
				HttpResponse httpResponse = httpClient.execute(httpPost);
				InputStream inputStream = httpResponse.getEntity().getContent();
				BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));
				StringBuilder sb = new StringBuilder(); String line = null;
				while((line = reader.readLine()) != null) { sb.append(line); }
				inputStream.close(); return sb.toString();
			}
			catch(Exception ex) { MessageBox("CONNECTION ERROR!"); }
			return null;
		}

		@Override protected void onPostExecute(String ResultSet) {
	
			try {

        		JSONObject jsonObj = new JSONObject(ResultSet);
				JSONArray jsonArry = jsonObj.getJSONArray("Response");
				JSONObject jsonResultSet = jsonArry.getJSONObject(0);
				Integer isValid = jsonResultSet.getInt("isValid");
				
				if(isValid.equals(1)) {
				
					myAccount = new Account(jsonResultSet.getInt("AccountID"), jsonResultSet.getString("AccountName"), jsonResultSet.getString("Username"));
					new CheckExistTask().execute(String.valueOf(myAccount.get_account_id()), String.valueOf(eflier_id), "CHECK_IF_EXIST_IN_STORAGE");
				}
				else { MessageBox("ACCOUNT DETAILS ERROR!"); }
			}
			catch(Exception ex) { MessageBox("JSON PARSING ERROR!"); }
		}
    }
	
	private class FetchEflier extends AsyncTask<String, String, String> {
		
		@Override protected String doInBackground(String... params) {
			
			List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>();
			String[] POST_VALUES = { "eflier_id", "function" };
        	for(int x = 0; x < params.length; x++) { nameValuePairs.add(new BasicNameValuePair(POST_VALUES[x], params[x])); }
        	
			try {
				
				HttpClient httpClient = new DefaultHttpClient();
				HttpPost httpPost = new HttpPost("http://" + myServer.localhost() + "/eflier/api/eflier_api.php");
				httpPost.setEntity(new UrlEncodedFormEntity(nameValuePairs));
				HttpResponse httpResponse = httpClient.execute(httpPost);
				InputStream inputStream = httpResponse.getEntity().getContent();
				BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));
				StringBuilder sb = new StringBuilder(); String line = null;
				while((line = reader.readLine()) != null) { sb.append(line); }
				inputStream.close(); return sb.toString();
			}
			catch(Exception ex) { MessageBox("CONNECTION ERROR!"); }
			return null;
		}

		@Override protected void onPostExecute(String ResultSet) {
	
        	try {

        		JSONObject jsonObj = new JSONObject(ResultSet);
	            JSONArray jsonArry = jsonObj.getJSONArray("Response");
	            JSONObject jsonResultSet = jsonArry.getJSONObject(0);
	            Integer isValid = jsonResultSet.getInt("isValid");
				
				if(isValid.equals(1)) {
				
					Eflier myEflier = new Eflier(jsonResultSet.getInt("eflier_id"), jsonResultSet.getString("eflier_subject"), jsonResultSet.getString("eflier_message"), jsonResultSet.getString("image_file"), jsonResultSet.getInt("department_id"), jsonResultSet.getInt("category_id"), jsonResultSet.getInt("styles_id"), jsonResultSet.getInt("broadcast_id"), jsonResultSet.getString("date_uploaded"));
					Style myStyle = new Style(jsonResultSet.getInt("styles_id"), jsonResultSet.getString("font_style"), jsonResultSet.getString("color_style"));
					GenerateEflier(myEflier, myStyle);
				}
			}
			catch(Exception ex) { MessageBox("ERROR RETRIEVING DATA!"); }
		}
    }

    private class CheckExistTask extends AsyncTask<String, String, String> {
			
		@Override protected String doInBackground(String... params) {
			
			List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>();
			String[] POST_VALUES = { "account_id", "eflier_id", "function" };
        	for(int x = 0; x < params.length; x++) { nameValuePairs.add(new BasicNameValuePair(POST_VALUES[x], params[x])); }
        	
			try {
				
				HttpClient httpClient = new DefaultHttpClient();
				HttpPost httpPost = new HttpPost("http://" + myServer.localhost() + "/eflier/api/eflier_api.php");
				httpPost.setEntity(new UrlEncodedFormEntity(nameValuePairs));
				HttpResponse httpResponse = httpClient.execute(httpPost);
				InputStream inputStream = httpResponse.getEntity().getContent();
				BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));
				StringBuilder sb = new StringBuilder(); String line = null;
				while((line = reader.readLine()) != null) { sb.append(line); }
				inputStream.close(); return sb.toString();
			}
			catch(Exception ex) { MessageBox("CONNECTION ERROR!"); }
			return null;
		}

		@Override protected void onPostExecute(String ResultSet) {
	
        	try {

        		JSONObject jsonObj = new JSONObject(ResultSet);
	            JSONArray jsonArry = jsonObj.getJSONArray("Response");
	            JSONObject jsonResultSet = jsonArry.getJSONObject(0);
	            Integer isValid = jsonResultSet.getInt("isValid");
				
				if(isValid.equals(1)) { isExisting = true; }
				new FetchEflier().execute(String.valueOf(eflier_id), "FETCH_EFLIER");
			}
			catch(Exception ex) { MessageBox("ERROR RETRIEVING DATA!"); }
		}
    }
    
    private void GenerateEflier(Eflier _eflier, Style _styles) {
		
		DynamicHandler dh = new DynamicHandler();
    	LayoutPanel.setPadding(30, 10, 30, 10);
		Typeface regular = Typeface.createFromAsset(getApplicationContext().getAssets(), "Raleway-Regular.ttf"), boldfont = Typeface.createFromAsset(getApplicationContext().getAssets(), "Raleway-Bold.ttf"), italicfont = Typeface.createFromAsset(getApplicationContext().getAssets(), "Raleway-Italic.ttf");
		String[] FontArray = { "REGULAR", "BOLD", "ITALIC" };
		String[] ColorArray = { "BLACK", "WHITE", "RED", "PURPLE", "BLUE", "GREEN" };
		
		TextView eflier_subject = new TextView(this);
		eflier_subject.setText(_eflier.eflier_subject);			
		eflier_subject.setTextSize(20);
		eflier_subject.setTypeface(boldfont);
		eflier_subject.setPadding(15, 10, 15, 10);
		eflier_subject.setGravity(Gravity.CENTER);
		eflier_subject.setBackgroundResource(R.drawable.border_top_radius);
		
		LayoutPanel.addView(eflier_subject);

		if(!_eflier.image_file.equals("null")) {
			
			ImageView myImageView = new ImageView(this);
			myImageView.setPadding(5, 0, 5, 10);
			Picasso.with(getApplicationContext()).load("http://" + myServer.localhost() + "/eflier/images/" + _eflier.image_file).resize(500, 500).centerCrop().into(myImageView);
			myImageView.setBackgroundResource(R.drawable.border_no_radius);
			LayoutPanel.addView(myImageView);
		} 
		else if(!_eflier.eflier_message.equals("null")) {
			
			TextView eflier_message = new TextView(this);
			eflier_message.setText(_eflier.eflier_message);
			eflier_message.setTextSize(40);
			eflier_message.setGravity(Gravity.CENTER_HORIZONTAL);
			eflier_message.setBackgroundResource(R.drawable.border_no_radius);
			eflier_message.setPadding(50, 50, 50, 50);
		
			String FontStyle = _styles.font_style;
			String ColorStyle = _styles.color_style;
			
			switch(Arrays.asList(FontArray).indexOf(FontStyle)) {
			
				case 0: eflier_message.setTypeface(regular); break;
				case 1: eflier_message.setTypeface(boldfont); break;
				case 2: eflier_message.setTypeface(italicfont); break;
			}
			
			switch(Arrays.asList(ColorArray).indexOf(ColorStyle)) {
			
				case 0: eflier_message.setBackgroundResource(R.color.black); eflier_message.setTextColor(getResources().getColor(R.color.white)); break;
				case 1: eflier_message.setBackgroundResource(R.color.white); eflier_message.setTextColor(getResources().getColor(R.color.black)); break;
				case 2: eflier_message.setBackgroundResource(R.color.red); eflier_message.setTextColor(getResources().getColor(R.color.white)); break;
				case 3: eflier_message.setBackgroundResource(R.color.purple); eflier_message.setTextColor(getResources().getColor(R.color.white)); break;
				case 4: eflier_message.setBackgroundResource(R.color.blue); eflier_message.setTextColor(getResources().getColor(R.color.black)); break;
				case 5: eflier_message.setBackgroundResource(R.color.green); eflier_message.setTextColor(getResources().getColor(R.color.black)); break;
			}
			
			LayoutPanel.addView(eflier_message);
		}
		
		Button myButton = new Button(this);
		myButton.setId(_eflier.eflier_id);
		myButton.setPadding(20, 10, 20, 10);
		myButton.setOnClickListener(dh);
		myButton.setBackgroundResource(R.drawable.border_bottom_radius);
		LayoutPanel.addView(myButton);
		
		if(!isExisting) {
			
			myButton.setText("SAVE EFLIER");
		}
		else {
			
			myButton.setText("DELETE EFLIER");
		}
    }
    
    private class StoreEflierTask extends AsyncTask<String, String, String> {

		private ProgressDialog myProgressDialog = null;
		
        @Override protected void onPreExecute() { myProgressDialog = ProgressDialog.show(ViewActivity.this, "SAVING EFLIER!", "Please Wait..."); }

        @Override protected String doInBackground(String... params) {
            
        	List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>();
        	String[] POST_VALUES = { "account_id", "eflier_id", "function" };
        	for(int x = 0; x < params.length; x++) { nameValuePairs.add(new BasicNameValuePair(POST_VALUES[x], params[x])); }
        	
			try {
				
				HttpClient httpClient = new DefaultHttpClient();
				HttpPost httpPost = new HttpPost("http://" + myServer.localhost() + "/eflier/api/eflier_api.php");
				httpPost.setEntity(new UrlEncodedFormEntity(nameValuePairs));
				HttpResponse httpResponse = httpClient.execute(httpPost);
				InputStream inputStream = httpResponse.getEntity().getContent();
				BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));
				StringBuilder sb = new StringBuilder(); String line = null;
				while((line = reader.readLine()) != null) { sb.append(line); }
				inputStream.close(); return sb.toString();
			}
			catch(Exception ex) { MessageBox("CONNECTION ERROR!"); }
			return null;
        }
        
        @Override protected void onPostExecute(String ResultSet) {
            
        	try {

				JSONObject jsonObj = new JSONObject(ResultSet);
				JSONArray jsonArry = jsonObj.getJSONArray("Response");
				JSONObject jsonResultSet = jsonArry.getJSONObject(0);
				Integer isValid = jsonResultSet.getInt("isValid");
				myProgressDialog.dismiss();
				
				if(isValid.equals(1)) {
					
					MessageBox("SUCCESSFULLY SAVED EFLIER!"); 
					finish();
				}
				else { MessageBox("UNABLE TO SAVE EFLIER!"); }
			} 
        	catch(Exception ex) { MessageBox("JSON PARSING ERROR!"); }
        }
    }
    
    private class DeleteEflierTask extends AsyncTask<String, String, String> {

		private ProgressDialog myProgressDialog = null;
		
        @Override protected void onPreExecute() { myProgressDialog = ProgressDialog.show(ViewActivity.this, "DELETING EFLIER!", "Please Wait..."); }

        @Override protected String doInBackground(String... params) {
            
        	List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>();
        	String[] POST_VALUES = { "account_id", "eflier_id", "function" };
        	for(int x = 0; x < params.length; x++) { nameValuePairs.add(new BasicNameValuePair(POST_VALUES[x], params[x])); }
        	
			try {
				
				HttpClient httpClient = new DefaultHttpClient();
				HttpPost httpPost = new HttpPost("http://" + myServer.localhost() + "/eflier/api/eflier_api.php");
				httpPost.setEntity(new UrlEncodedFormEntity(nameValuePairs));
				HttpResponse httpResponse = httpClient.execute(httpPost);
				InputStream inputStream = httpResponse.getEntity().getContent();
				BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));
				StringBuilder sb = new StringBuilder(); String line = null;
				while((line = reader.readLine()) != null) { sb.append(line); }
				inputStream.close(); return sb.toString();
			}
			catch(Exception ex) { MessageBox("CONNECTION ERROR!"); }
			return null;
        }
        
        @Override protected void onPostExecute(String ResultSet) {
            
        	try {

				JSONObject jsonObj = new JSONObject(ResultSet);
				JSONArray jsonArry = jsonObj.getJSONArray("Response");
				JSONObject jsonResultSet = jsonArry.getJSONObject(0);
				Integer isValid = jsonResultSet.getInt("isValid");
				myProgressDialog.dismiss();
				
				if(isValid.equals(1)) {
					
					MessageBox("SUCCESSFULLY DELETED EFLIER!"); 
					finish();
				}
				else { MessageBox("UNABLE TO DELETE EFLIER!"); }
			} 
        	catch(Exception ex) { MessageBox("JSON PARSING ERROR!"); }
        }
    }
    
    private class DynamicHandler implements OnClickListener {
		
		@Override public void onClick(View v) {
		
			Button myButton = (Button) v;
			if(myButton.getText() == "SAVE EFLIER") {
				
				new StoreEflierTask().execute(String.valueOf(myAccount.get_account_id()), String.valueOf(v.getId()), "STORE_EFLIER");
			}
			else if(myButton.getText() == "DELETE EFLIER") {
				
				new DeleteEflierTask().execute(String.valueOf(myAccount.get_account_id()), String.valueOf(v.getId()), "DELETE_EFLIER");
			}
		}
	}
    
    private void MessageBox(final String myMessage) {
	    
		runOnUiThread(new Runnable() {
			
			@Override public void run() {
				
				Toast.makeText(getApplicationContext(), myMessage, Toast.LENGTH_SHORT).show();
			}
		});
	}
}
