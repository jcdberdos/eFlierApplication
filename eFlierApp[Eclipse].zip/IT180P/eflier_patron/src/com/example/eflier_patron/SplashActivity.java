package com.example.eflier_patron;

import java.util.Timer;
import java.util.TimerTask;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;

public class SplashActivity extends Activity {
	
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);
        
        final Timer myTimer = new Timer();
        final Handler myHandler = new Handler();    
		
        TimerTask myTimerTask = new TimerTask() { @Override public void run() { myHandler.post(new Runnable() { 
        	public void run() {
				
	        	myTimer.cancel();
				Intent myIntent = new Intent(SplashActivity.this, LoginActivity.class);
				startActivity(myIntent);
				finish();
        	}
        });}};

		myTimer.schedule(myTimerTask, 1500);
    }
}