package com.example.eflier_patron;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONArray;
import org.json.JSONObject;

import com.example.models.Account;
import com.example.models.Eflier;
import com.example.models.Server;
import com.example.models.Style;
import com.squareup.picasso.Picasso;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Typeface;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

@SuppressWarnings({"deprecation", "resource"})
public class StorageActivity extends Activity {

	private Server myServer = new Server();
	private Account myAccount = null;
	private LinearLayout LayoutPanel;
	private Spinner CategorySpinner;
	
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_storage);
        
        /* INSTANTIATE OBJECTS */
        LayoutPanel = (LinearLayout) findViewById(R.id.sa_layout_panel_1);
        CategorySpinner = (Spinner) findViewById(R.id.category_spinner_2);
        
        /* INSTANTIATE HANDLERS */
        CategoryHandler ch = new CategoryHandler();
        
        /* SET EVENT LISTENERS */
        CategorySpinner.setOnItemSelectedListener(ch); 
        
        /* SET ACCOUNT INFO */
        int myAccountID = getIntent().getExtras().getInt("AccountID");
        myAccount = new Account(myAccountID, null, null);
        new FetchAccount().execute(String.valueOf(myAccountID), "FETCH_ACCOUNT");    
        new FetchCategories().execute("FETCH_CATEGORIES");
    } 
    
    private class CategoryHandler implements OnItemSelectedListener {
		
		@Override public void onItemSelected(AdapterView<?> arg0, View arg1, int myIndex, long arg3) {
	    
			LayoutPanel.removeAllViews();
			
			if(myIndex != 0) {
			
				new FetchEfliersCategory().execute(String.valueOf(myAccount.get_account_id()), String.valueOf(myIndex), "FETCH_EFLIERS_BY_STORAGE_CATEGORY"); 
			}
			else {
				
				new FetchEfliers().execute(String.valueOf(myAccount.get_account_id()), "FETCH_EFLIERS_BY_STORAGE");
			}
	    }
		
		@Override public void onNothingSelected(AdapterView<?> arg0) { /* DO NOTHING HERE... */ }
	}
    
    private class FetchEfliersCategory extends AsyncTask<String, String, String> {
		
		@Override protected String doInBackground(String... params) {
			
			List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>();
			String[] POST_VALUES = { "account_id", "category_id", "function" };
        	for(int x = 0; x < params.length; x++) { nameValuePairs.add(new BasicNameValuePair(POST_VALUES[x], params[x])); }
			
			try {
				
				HttpClient httpClient = new DefaultHttpClient();
				HttpPost httpPost = new HttpPost("http://" + myServer.localhost() + "/eflier/api/eflier_api.php");
				httpPost.setEntity(new UrlEncodedFormEntity(nameValuePairs));
				HttpResponse httpResponse = httpClient.execute(httpPost);
				InputStream inputStream = httpResponse.getEntity().getContent();
				BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));
				StringBuilder sb = new StringBuilder(); String line = null;
				while((line = reader.readLine()) != null) { sb.append(line); }
				inputStream.close(); return sb.toString();
			}
			catch(Exception ex) { MessageBox("CONNECTION ERROR!"); }
			return null;
		}

		@Override protected void onPostExecute(String ResultSet) {
	
        	try {

        		JSONObject jsonObj = new JSONObject(ResultSet);
	            JSONArray jsonArry = jsonObj.getJSONArray("Response");
	            List<Eflier> eflier_list = new ArrayList<Eflier>();
	            List<Style> styles_list = new ArrayList<Style>();

	            for(int x = 0; x < jsonArry.length(); x++) {

	                JSONObject jsonResultSet = jsonArry.getJSONObject(x);    
	                Integer isValid = jsonResultSet.getInt("isValid");
					
					if(isValid.equals(1)) {
					
						Eflier _eflier = new Eflier(jsonResultSet.getInt("eflier_id"), jsonResultSet.getString("eflier_subject"), jsonResultSet.getString("eflier_message"), jsonResultSet.getString("image_file"), jsonResultSet.getInt("department_id"), jsonResultSet.getInt("category_id"), jsonResultSet.getInt("styles_id"), jsonResultSet.getInt("broadcast_id"), jsonResultSet.getString("date_uploaded"));
		                Style _style = new Style(jsonResultSet.getInt("styles_id"), jsonResultSet.getString("font_style"), jsonResultSet.getString("color_style"));
		                eflier_list.add(_eflier); styles_list.add(_style);
					}
	            }
	            
	            GenerateViews(eflier_list, styles_list);
			}
			catch(Exception ex) { MessageBox("JSON PARSING ERROR!"); }
		}
    }
    
    private class FetchAccount extends AsyncTask<String, String, String> {
		
		@Override protected String doInBackground(String... params) {
			
			List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>();
			String[] POST_VALUES = { "account_id", "function" };
        	for(int x = 0; x < params.length; x++) { nameValuePairs.add(new BasicNameValuePair(POST_VALUES[x], params[x])); }
			
			try {
				
				HttpClient httpClient = new DefaultHttpClient();
				HttpPost httpPost = new HttpPost("http://" + myServer.localhost() + "/eflier/api/account_api.php");
				httpPost.setEntity(new UrlEncodedFormEntity(nameValuePairs));
				HttpResponse httpResponse = httpClient.execute(httpPost);
				InputStream inputStream = httpResponse.getEntity().getContent();
				BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));
				StringBuilder sb = new StringBuilder(); String line = null;
				while((line = reader.readLine()) != null) { sb.append(line); }
				inputStream.close(); return sb.toString();
			}
			catch(Exception ex) { MessageBox("CONNECTION ERROR!"); }
			return null;
		}

		@Override protected void onPostExecute(String ResultSet) {
	
			try {

        		JSONObject jsonObj = new JSONObject(ResultSet);
				JSONArray jsonArry = jsonObj.getJSONArray("Response");
				JSONObject jsonResultSet = jsonArry.getJSONObject(0);
				Integer isValid = jsonResultSet.getInt("isValid");
				
				if(isValid.equals(1)) {
				
					myAccount = new Account(jsonResultSet.getInt("AccountID"), jsonResultSet.getString("AccountName"), jsonResultSet.getString("Username"));					
				}
				else { MessageBox("ACCOUNT DETAILS ERROR!"); }
			}
			catch(Exception ex) { MessageBox("JSON PARSING ERROR!"); }
		}
    }

    private class FetchEfliers extends AsyncTask<String, String, String> {
			
		@Override protected String doInBackground(String... params) {
			
			List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>();
			String[] POST_VALUES = { "account_id", "function" };
        	for(int x = 0; x < params.length; x++) { nameValuePairs.add(new BasicNameValuePair(POST_VALUES[x], params[x])); }
        	
			try {
				
				HttpClient httpClient = new DefaultHttpClient();
				HttpPost httpPost = new HttpPost("http://" + myServer.localhost() + "/eflier/api/eflier_api.php");
				httpPost.setEntity(new UrlEncodedFormEntity(nameValuePairs));
				HttpResponse httpResponse = httpClient.execute(httpPost);
				InputStream inputStream = httpResponse.getEntity().getContent();
				BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));
				StringBuilder sb = new StringBuilder(); String line = null;
				while((line = reader.readLine()) != null) { sb.append(line); }
				inputStream.close(); return sb.toString();
			}
			catch(Exception ex) { MessageBox("CONNECTION ERROR!"); }
			return null;
		}

		@Override protected void onPostExecute(String ResultSet) {
	
			try {

        		JSONObject jsonObj = new JSONObject(ResultSet);
	            JSONArray jsonArry = jsonObj.getJSONArray("Response");
	            List<Eflier> eflier_list = new ArrayList<Eflier>();
	            List<Style> styles_list = new ArrayList<Style>();
	            
	            for(int x = 0; x < jsonArry.length(); x++) {

	                JSONObject jsonResultSet = jsonArry.getJSONObject(x);    
	                Integer isValid = jsonResultSet.getInt("isValid");

					if(isValid.equals(1)) {
					
						Eflier _eflier = new Eflier(jsonResultSet.getInt("eflier_id"), jsonResultSet.getString("eflier_subject"), jsonResultSet.getString("eflier_message"), jsonResultSet.getString("image_file"), jsonResultSet.getInt("department_id"), jsonResultSet.getInt("category_id"), jsonResultSet.getInt("styles_id"), jsonResultSet.getInt("broadcast_id"), jsonResultSet.getString("date_uploaded"));
		                Style _style = new Style(jsonResultSet.getInt("styles_id"), jsonResultSet.getString("font_style"), jsonResultSet.getString("color_style"));
		                eflier_list.add(_eflier); styles_list.add(_style);
					}
	            }
	            
	            GenerateViews(eflier_list, styles_list);
			}
			catch(Exception ex) { MessageBox("JSON PARSING ERROR!"); }
		}
    }
    
    private class FetchCategories extends AsyncTask<String, String, String> {
		
		@Override protected String doInBackground(String... params) {
			
			List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>();
			String[] POST_VALUES = { "function" };
        	for(int x = 0; x < params.length; x++) { nameValuePairs.add(new BasicNameValuePair(POST_VALUES[x], params[x])); }
			
			try {
				
				HttpClient httpClient = new DefaultHttpClient();
				HttpPost httpPost = new HttpPost("http://" + myServer.localhost() + "/eflier/api/eflier_api.php");
				httpPost.setEntity(new UrlEncodedFormEntity(nameValuePairs));
				HttpResponse httpResponse = httpClient.execute(httpPost);
				InputStream inputStream = httpResponse.getEntity().getContent();
				BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));
				StringBuilder sb = new StringBuilder(); String line = null;
				while((line = reader.readLine()) != null) { sb.append(line); }
				inputStream.close(); return sb.toString();
			}
			catch(Exception ex) { MessageBox("CONNECTION ERROR!"); }
			return null;
		}

		@Override protected void onPostExecute(String ResultSet) {
	
        	try {

        		List<String> data = new ArrayList<String>(); data.add("Choose Filter...");
        		JSONObject jsonObj = new JSONObject(ResultSet);
				JSONArray jsonArry = jsonObj.getJSONArray("Response");
				
				for(int x = 0; x < jsonArry.length(); x++)
				{
					JSONObject jsonResultSet = jsonArry.getJSONObject(x);
					Integer isValid = jsonResultSet.getInt("isValid");
					
					if(isValid.equals(1)) {
						       
						data.add(jsonResultSet.getString("Category"));
					}
				}
				
				ArrayAdapter<String> adapter = new ArrayAdapter<String>(getApplicationContext(), android.R.layout.simple_spinner_item, data);
		        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
		        CategorySpinner.setAdapter(adapter);
        	}
			catch(Exception ex) { MessageBox("JSON PARSING ERROR!"); }
		}
	}
	
	private void GenerateViews(List<Eflier> eflier_list, List<Style> styles_list) {
		
		int x = 0;
		LayoutPanel.setPadding(30, 10, 30, 10);
		DynamicHandler dh = new DynamicHandler();
		Typeface regular = Typeface.createFromAsset(getApplicationContext().getAssets(), "Raleway-Regular.ttf"), boldfont = Typeface.createFromAsset(getApplicationContext().getAssets(), "Raleway-Bold.ttf"), italicfont = Typeface.createFromAsset(getApplicationContext().getAssets(), "Raleway-Italic.ttf");
		String[] FontArray = { "REGULAR", "BOLD", "ITALIC" };
		String[] ColorArray = { "BLACK", "WHITE", "RED", "PURPLE", "BLUE", "GREEN" };
		
		for(Eflier _eflier: eflier_list)
		{	
			TextView padding = new TextView(this);
			padding.setTextSize(20);
			padding.setPadding(20, 80, 0, 5);
			LayoutPanel.addView(padding);
			
			TextView eflier_subject = new TextView(this);
			eflier_subject.setText(_eflier.eflier_subject);			
			eflier_subject.setTextSize(20);
			eflier_subject.setTypeface(boldfont);
			eflier_subject.setPadding(15, 10, 15, 10);
			eflier_subject.setGravity(Gravity.CENTER);
			eflier_subject.setBackgroundResource(R.drawable.border_top_radius);
			
			LayoutPanel.addView(eflier_subject);

			if(!_eflier.image_file.equals("null")) {
				
				ImageView myImageView = new ImageView(this);
				myImageView.setPadding(5, 0, 5, 10);
				Picasso.with(getApplicationContext()).load("http://" + myServer.localhost() + "/eflier/images/" + _eflier.image_file).resize(500, 500).centerCrop().into(myImageView);
				myImageView.setBackgroundResource(R.drawable.border_no_radius);
				LayoutPanel.addView(myImageView);
			} 
			else if(!_eflier.eflier_message.equals("null")) {
				
				TextView eflier_message = new TextView(this);
				eflier_message.setText(_eflier.eflier_message);
				eflier_message.setTextSize(40);
				eflier_message.setGravity(Gravity.CENTER_HORIZONTAL);
				eflier_message.setBackgroundResource(R.drawable.border_no_radius);
				eflier_message.setPadding(50, 50, 50, 50);
			
				String FontStyle = styles_list.get(x).font_style;
				String ColorStyle = styles_list.get(x).color_style;	
				
				switch(Arrays.asList(FontArray).indexOf(FontStyle)) {
				
					case 0: eflier_message.setTypeface(regular); break;
					case 1: eflier_message.setTypeface(boldfont); break;
					case 2: eflier_message.setTypeface(italicfont); break;
				}
				
				switch(Arrays.asList(ColorArray).indexOf(ColorStyle)) {
				
					case 0: eflier_message.setBackgroundResource(R.color.black); eflier_message.setTextColor(getResources().getColor(R.color.white)); break;
					case 1: eflier_message.setBackgroundResource(R.color.white); eflier_message.setTextColor(getResources().getColor(R.color.black)); break;
					case 2: eflier_message.setBackgroundResource(R.color.red); eflier_message.setTextColor(getResources().getColor(R.color.white)); break;
					case 3: eflier_message.setBackgroundResource(R.color.purple); eflier_message.setTextColor(getResources().getColor(R.color.white)); break;
					case 4: eflier_message.setBackgroundResource(R.color.blue); eflier_message.setTextColor(getResources().getColor(R.color.black)); break;
					case 5: eflier_message.setBackgroundResource(R.color.green); eflier_message.setTextColor(getResources().getColor(R.color.black)); break;
				}
				
				LayoutPanel.addView(eflier_message);
			}
			
			Button myButton = new Button(this);
			myButton.setId(_eflier.eflier_id);
			myButton.setText("VIEW EFLIER");
			myButton.setPadding(20, 10, 20, 10);
			myButton.setOnClickListener(dh);
			myButton.setBackgroundResource(R.drawable.border_bottom_radius);
			LayoutPanel.addView(myButton);
			x++;
		}
	}
	
	private class DynamicHandler implements OnClickListener {
		
		@Override public void onClick(View v) {
		
			Bundle myBundle = new Bundle();
			myBundle.putInt("account_id", myAccount.get_account_id());
			myBundle.putInt("eflier_id", v.getId());
			Intent myIntent = new Intent(StorageActivity.this, ViewActivity.class);
			myIntent.putExtras(myBundle);
			startActivity(myIntent);
		}
	}
	
	private void MessageBox(final String myMessage) {
	    
		runOnUiThread(new Runnable() {
			
			@Override public void run() {
				
				Toast.makeText(getApplicationContext(), myMessage, Toast.LENGTH_SHORT).show();
			}
		});
	}
}
