package com.example.models;

public class Eflier {

	public int eflier_id = 0, department_id = 0, category_id = 0, styles_id = 0, broadcast_id = 0;
	public String eflier_subject = null, eflier_message = null, image_file = null, date_uploaded = null;
    
    public Eflier(int eflier_id, String eflier_subject, String eflier_message, String image_file, int department_id, int category_id, int styles_id, int broadcast_id, String date_uploaded) {
    	
    	this.eflier_id = eflier_id;
    	this.eflier_subject = eflier_subject;
    	this.eflier_message = eflier_message;
    	this.image_file = image_file;
    	this.department_id = department_id;
        this.category_id = category_id;
        this.styles_id = styles_id;
        this.broadcast_id = broadcast_id;
        this.date_uploaded = date_uploaded;
    }
}