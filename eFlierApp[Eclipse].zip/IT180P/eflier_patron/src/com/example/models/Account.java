package com.example.models;

public class Account {

	private int _account_id = 0;
    private String _account_name = null;
    private String _username = null;
    
    public Account(int account_id, String account_name, String _username) {
    	
    	this._account_id = account_id;
    	this._account_name = account_name;
    	this._username = _username;
    }
    
    public int get_account_id() 
    {
        return this._account_id;
    }

    public String get_account_name() 
    {
        return this._account_name;
    }

    public String get_username() 
    {
        return this._username;
    }
}