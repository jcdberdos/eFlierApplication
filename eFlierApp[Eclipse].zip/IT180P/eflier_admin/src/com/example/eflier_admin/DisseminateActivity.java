package com.example.eflier_admin;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.StringTokenizer;

import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONArray;
import org.json.JSONObject;

import com.example.models.Broadcast;
import com.example.models.Department;
import com.example.models.Eflier;
import com.example.models.Server;
import com.example.models.Style;
import com.squareup.picasso.Picasso;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

@SuppressLint("ResourceAsColor")
@SuppressWarnings({"deprecation", "resource"})
public class DisseminateActivity extends Activity {

	private Server myServer = new Server();
	private Department myDepartment = null;
	private LinearLayout LayoutPanel;
	private Spinner CategorySpinner;
	private String[] Months = { "JAN", "FEB", "MAR", "APR", "MAY", "JUN", "JUL", "AUG", "SEP", "OCT", "NOV", "DEC" };
	
	@Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_disseminate);
        
        /* INSTANTIATE OBJECTS */
        LayoutPanel = (LinearLayout) findViewById(R.id.dm_LayoutPanel);
        CategorySpinner = (Spinner) findViewById(R.id.category_spinner_2);
        
        /* INSTANTIATE HANDLERS */
        CategoryHandler ch = new CategoryHandler();
        
        /* SET EVENT LISTENERS */
        CategorySpinner.setOnItemSelectedListener(ch); 
        
        /* SET DEPARTMENT INFO */
        int myDepartmentID = getIntent().getExtras().getInt("DepartmentID");
        myDepartment = new Department(myDepartmentID, null, null);
        new FetchDepartment().execute(String.valueOf(myDepartmentID), "FETCH_DEPARTMENT"); 
        new FetchCategories().execute("FETCH_CATEGORIES");
	}
	
	private class CategoryHandler implements OnItemSelectedListener {
		
		@Override public void onItemSelected(AdapterView<?> arg0, View arg1, int myIndex, long arg3) {
	    
			if(myIndex != 0) {
			
				LayoutPanel.removeAllViews();
				new FetchEfliersCategory().execute(String.valueOf(myDepartment.get_department_id()), String.valueOf(myIndex), "FETCH_EFLIERS_BY_DEPARTMENT_CATEGORY"); 
			}
	    }
		
		@Override public void onNothingSelected(AdapterView<?> arg0) { /* DO NOTHING HERE... */ }
	}
	
	private class FetchEfliers extends AsyncTask<String, String, String> {
			
		@Override protected String doInBackground(String... params) {
			
			List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>();
			String[] POST_VALUES = { "department_id", "function" };
        	for(int x = 0; x < params.length; x++) { nameValuePairs.add(new BasicNameValuePair(POST_VALUES[x], params[x])); }
			
			try {
				
				HttpClient httpClient = new DefaultHttpClient();
				HttpPost httpPost = new HttpPost("http://" + myServer.localhost() + "/eflier/api/eflier_api.php");
				httpPost.setEntity(new UrlEncodedFormEntity(nameValuePairs));
				HttpResponse httpResponse = httpClient.execute(httpPost);
				InputStream inputStream = httpResponse.getEntity().getContent();
				BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));
				StringBuilder sb = new StringBuilder(); String line = null;
				while((line = reader.readLine()) != null) { sb.append(line); }
				inputStream.close(); return sb.toString();
			}
			catch(Exception ex) { MessageBox("CONNECTION ERROR!"); }
			return null;
		}

		@Override protected void onPostExecute(String ResultSet) {
	
        	try {

        		JSONObject jsonObj = new JSONObject(ResultSet);
	            JSONArray jsonArry = jsonObj.getJSONArray("Response");
	            List<Eflier> eflier_list = new ArrayList<Eflier>();
	            List<Style> styles_list = new ArrayList<Style>();
	            List<Broadcast> broadcast_list = new ArrayList<Broadcast>();
	            
	            for(int x = 0; x < jsonArry.length(); x++) {

	                JSONObject jsonResultSet = jsonArry.getJSONObject(x);    
	                Integer isValid = jsonResultSet.getInt("isValid");
					
					if(isValid.equals(1)) {
					
						Eflier _eflier = new Eflier(jsonResultSet.getInt("eflier_id"), jsonResultSet.getString("eflier_subject"), jsonResultSet.getString("eflier_message"), jsonResultSet.getString("image_file"), jsonResultSet.getInt("department_id"), jsonResultSet.getInt("category_id"), jsonResultSet.getInt("styles_id"), jsonResultSet.getInt("broadcast_id"), jsonResultSet.getString("date_uploaded"));
		                Style _style = new Style(jsonResultSet.getInt("styles_id"), jsonResultSet.getString("font_style"), jsonResultSet.getString("color_style"));
		                Broadcast _broadcast = new Broadcast(jsonResultSet.getInt("broadcast_id"), jsonResultSet.getString("bc_start_date"), jsonResultSet.getString("bc_start_time"), jsonResultSet.getString("bc_end_date"), jsonResultSet.getString("bc_end_time"));
		                eflier_list.add(_eflier); styles_list.add(_style); broadcast_list.add(_broadcast);
					}
	            }
	            
	            GenerateViews(eflier_list, styles_list, broadcast_list);
			}
			catch(Exception ex) { MessageBox("JSON PARSING ERROR!"); }
		}
    }
	
	private class FetchEfliersCategory extends AsyncTask<String, String, String> {
		
		@Override protected String doInBackground(String... params) {
			
			List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>();
			String[] POST_VALUES = { "department_id", "category_id", "function" };
        	for(int x = 0; x < params.length; x++) { nameValuePairs.add(new BasicNameValuePair(POST_VALUES[x], params[x])); }
			
			try {
				
				HttpClient httpClient = new DefaultHttpClient();
				HttpPost httpPost = new HttpPost("http://" + myServer.localhost() + "/eflier/api/eflier_api.php");
				httpPost.setEntity(new UrlEncodedFormEntity(nameValuePairs));
				HttpResponse httpResponse = httpClient.execute(httpPost);
				InputStream inputStream = httpResponse.getEntity().getContent();
				BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));
				StringBuilder sb = new StringBuilder(); String line = null;
				while((line = reader.readLine()) != null) { sb.append(line); }
				inputStream.close(); return sb.toString();
			}
			catch(Exception ex) { MessageBox("CONNECTION ERROR!"); }
			return null;
		}

		@Override protected void onPostExecute(String ResultSet) {
	
        	try {

        		JSONObject jsonObj = new JSONObject(ResultSet);
	            JSONArray jsonArry = jsonObj.getJSONArray("Response");
	            List<Eflier> eflier_list = new ArrayList<Eflier>();
	            List<Style> styles_list = new ArrayList<Style>();
	            List<Broadcast> broadcast_list = new ArrayList<Broadcast>();
	            
	            for(int x = 0; x < jsonArry.length(); x++) {

	                JSONObject jsonResultSet = jsonArry.getJSONObject(x);    
	                Integer isValid = jsonResultSet.getInt("isValid");
					
					if(isValid.equals(1)) {
					
						Eflier _eflier = new Eflier(jsonResultSet.getInt("eflier_id"), jsonResultSet.getString("eflier_subject"), jsonResultSet.getString("eflier_message"), jsonResultSet.getString("image_file"), jsonResultSet.getInt("department_id"), jsonResultSet.getInt("category_id"), jsonResultSet.getInt("styles_id"), jsonResultSet.getInt("broadcast_id"), jsonResultSet.getString("date_uploaded"));
		                Style _style = new Style(jsonResultSet.getInt("styles_id"), jsonResultSet.getString("font_style"), jsonResultSet.getString("color_style"));
		                Broadcast _broadcast = new Broadcast(jsonResultSet.getInt("broadcast_id"), jsonResultSet.getString("bc_start_date"), jsonResultSet.getString("bc_start_time"), jsonResultSet.getString("bc_end_date"), jsonResultSet.getString("bc_end_time"));
		                eflier_list.add(_eflier); styles_list.add(_style); broadcast_list.add(_broadcast);
					}
	            }
	            
	            GenerateViews(eflier_list, styles_list, broadcast_list);
			}
			catch(Exception ex) { MessageBox("JSON PARSING ERROR!"); }
		}
    }
	
	@SuppressLint({ "ResourceAsColor", "DefaultLocale" })
	private void GenerateViews(List<Eflier> eflier_list, List<Style> styles_list, List<Broadcast> broadcast_list) {
		
		int x = 0;
		LayoutPanel.setPadding(30, 10, 30, 10);
		DynamicHandler dh = new DynamicHandler();
		ButtonHandler1 bh1 = new ButtonHandler1();
		ButtonHandler2 bh2 = new ButtonHandler2();
		Typeface regular = Typeface.createFromAsset(getApplicationContext().getAssets(), "Raleway-Regular.ttf"), boldfont = Typeface.createFromAsset(getApplicationContext().getAssets(), "Raleway-Bold.ttf"), italicfont = Typeface.createFromAsset(getApplicationContext().getAssets(), "Raleway-Italic.ttf");
		String[] FontArray = { "REGULAR", "BOLD", "ITALIC" };
		String[] ColorArray = { "BLACK", "WHITE", "RED", "PURPLE", "BLUE", "GREEN" };
		
		for(Eflier _eflier: eflier_list)
		{	
			TextView padding = new TextView(this);
			padding.setTextSize(20);
			padding.setPadding(20, 80, 0, 5);
			LayoutPanel.addView(padding);
			
			TextView eflier_subject = new TextView(this);
			
			eflier_subject.setText(_eflier.eflier_subject.toUpperCase());			
			eflier_subject.setTextSize(20);
			eflier_subject.setTypeface(boldfont);
			eflier_subject.setPadding(15, 10, 10, 15);
			eflier_subject.setGravity(Gravity.CENTER);
			
			if(IsBroadcasting(broadcast_list.get(x))) { eflier_subject.setBackgroundResource(R.drawable.border_top_radius_broadcasting); }
			else { eflier_subject.setBackgroundResource(R.drawable.border_top_radius_notbroadcasting); }
			
			LayoutPanel.addView(eflier_subject);
			
			TextView eflier_broadcastTime = new TextView(this);
			eflier_broadcastTime.setText(ToTime(broadcast_list.get(x).bc_start_time) + " - " + ToTime(broadcast_list.get(x).bc_end_time));
			eflier_broadcastTime.setTextSize(12);
			eflier_broadcastTime.setTypeface(regular);
			eflier_broadcastTime.setPadding(10, 5, 0, 5);
			eflier_broadcastTime.setGravity(Gravity.CENTER);
			eflier_broadcastTime.setBackgroundResource(R.drawable.border_no_radius);
			
			LayoutPanel.addView(eflier_broadcastTime);
			
			TextView eflier_broadcastDate = new TextView(this);
			eflier_broadcastDate.setText(ToDate(broadcast_list.get(x).bc_start_date) + " - " + ToDate(broadcast_list.get(x).bc_end_date));
			eflier_broadcastDate.setTextSize(12);
			eflier_broadcastDate.setTypeface(regular);
			eflier_broadcastDate.setPadding(10, 5, 0, 5);
			eflier_broadcastDate.setGravity(Gravity.CENTER);
			eflier_broadcastDate.setBackgroundResource(R.drawable.border_no_radius);
			
			LayoutPanel.addView(eflier_broadcastDate);

			Button editButton = new Button(this);
			editButton.setId(_eflier.eflier_id);
			editButton.setText("EDIT EFLIER");
			editButton.setTextColor(Color.WHITE);
			editButton.setTypeface(boldfont);
			editButton.setTextSize(TypedValue.COMPLEX_UNIT_SP, 20);
			editButton.setBackgroundResource(R.drawable.border_bottom_radius);
			
			if(!_eflier.image_file.equals("null")) {
				
				ImageView myImageView = new ImageView(this);
				myImageView.setPadding(5, 10, 5, 10);
				Picasso.with(getApplicationContext()).load("http://" + myServer.localhost() + "/eflier/images/" + _eflier.image_file).resize(500, 500).centerCrop().into(myImageView);
				myImageView.setBackgroundResource(R.drawable.border_no_radius);
				editButton.setOnClickListener(bh1);
				LayoutPanel.addView(myImageView);
			} 
			else if(!_eflier.eflier_message.equals("null")) {
				
				TextView eflier_message = new TextView(this);
				eflier_message.setText(_eflier.eflier_message);
				eflier_message.setTextSize(40);
				eflier_message.setGravity(Gravity.CENTER_HORIZONTAL);
				eflier_message.setPadding(50, 50, 50, 50);
				eflier_message.setBackgroundResource(R.drawable.border_no_radius);
			
				String FontStyle = styles_list.get(x).font_style;
				String ColorStyle = styles_list.get(x).color_style;	
				
				switch(Arrays.asList(FontArray).indexOf(FontStyle)) {
				
					case 0: eflier_message.setTypeface(regular); break;
					case 1: eflier_message.setTypeface(boldfont); break;
					case 2: eflier_message.setTypeface(italicfont); break;
				}
				
				switch(Arrays.asList(ColorArray).indexOf(ColorStyle)) {
				
					case 0: eflier_message.setBackgroundResource(R.color.black); eflier_message.setTextColor(getResources().getColor(R.color.white)); break;
					case 1: eflier_message.setBackgroundResource(R.color.white); eflier_message.setTextColor(getResources().getColor(R.color.black)); break;
					case 2: eflier_message.setBackgroundResource(R.color.red); eflier_message.setTextColor(getResources().getColor(R.color.white)); break;
					case 3: eflier_message.setBackgroundResource(R.color.purple); eflier_message.setTextColor(getResources().getColor(R.color.white)); break;
					case 4: eflier_message.setBackgroundResource(R.color.blue); eflier_message.setTextColor(getResources().getColor(R.color.black)); break;
					case 5: eflier_message.setBackgroundResource(R.color.green); eflier_message.setTextColor(getResources().getColor(R.color.black)); break;
				}
				
				editButton.setOnClickListener(bh2);
				LayoutPanel.addView(eflier_message);
			}
			
			Button myButton = new Button(this);
			myButton.setId(_eflier.broadcast_id);
			myButton.setText("BROADCAST");
			myButton.setPadding(20, 10, 20, 10);
			myButton.setTypeface(boldfont);
			myButton.setTextColor(Color.WHITE);
			myButton.setTextSize(TypedValue.COMPLEX_UNIT_SP, 20);
			myButton.setOnClickListener(dh);
			myButton.setBackgroundResource(R.drawable.border_no_radius_2);
			LayoutPanel.addView(myButton);
			LayoutPanel.addView(editButton);
			x++;
		}
	}
	
	private boolean IsBroadcasting(Broadcast broadcast_info) {
		
		SimpleDateFormat sdf = null;
		sdf = new SimpleDateFormat("yyyy-MM-dd");
		//Date current_date = new Date();
		
		try {
		
			Date start_date = sdf.parse(broadcast_info.bc_start_date), end_date = sdf.parse(broadcast_info.bc_end_date);
		
			if(System.currentTimeMillis() > start_date.getTime() && System.currentTimeMillis() < end_date.getTime())
			{
				return true;
				
				/*
				sdf = new SimpleDateFormat("HH:mm:ss");
				Date start_time = sdf.parse(broadcast_info.bc_start_time), end_time = sdf.parse(broadcast_info.bc_end_time);
				
				if((start_time.getTime() + current_date.getDate()) > System.currentTimeMillis() && (end_time.getTime() + current_date.getDate()) < System.currentTimeMillis())
				{
					MessageBox("GOODS");
					return true;
				}
				else { return false; }
				*/
			}
			else { return false; }
		}
		catch(Exception ex) { MessageBox("DATE/TIME PARSING ERROR!"); }
		return false;
	}
	
	private String ToTime(String myTime) {
		
		try {
			
			SimpleDateFormat sdf = new SimpleDateFormat("HH:mm:ss");
		    Date dateObj = sdf.parse(myTime);
		    return new SimpleDateFormat("hh:mm a").format(dateObj);
		}
		catch (Exception ex) { MessageBox("DATE/TIME FORMATTING ERROR"); }
		return null;
	}
	
	private String ToDate(String myDate) {
		
		StringTokenizer st = new StringTokenizer(myDate, "-");
		int myYear = Integer.parseInt(st.nextToken());
		String myMonth = Months[Integer.parseInt(st.nextToken()) - 1];
		int myDay = Integer.parseInt(st.nextToken());
		return myMonth + " " + myDay + ", " + myYear;
	}
	
	private class DynamicHandler implements OnClickListener {
		
		@Override public void onClick(View v) {
			
			Bundle b = new Bundle();
			b.putInt("eflier_id", v.getId());
			b.putInt("DepartmentID", myDepartment.get_department_id());
			Intent i = new Intent(DisseminateActivity.this, BroadcastActivity.class);
			i.putExtras(b);
			startActivity(i);
		}
	}
	
	private class ButtonHandler1 implements OnClickListener {
		
		@Override public void onClick(View v) {
			
			Bundle b = new Bundle();
			b.putInt("eflier_id", v.getId());
			b.putInt("DepartmentID", myDepartment.get_department_id());
			Intent i = new Intent(DisseminateActivity.this, EditImageActivity.class);
			i.putExtras(b);
			startActivity(i);
		}
	}
	
	private class ButtonHandler2 implements OnClickListener {
		
		@Override public void onClick(View v) {
			
			Bundle b = new Bundle();
			b.putInt("eflier_id", v.getId());
			b.putInt("DepartmentID", myDepartment.get_department_id());
			Intent i = new Intent(DisseminateActivity.this, EditTextActivity.class);
			i.putExtras(b);
			startActivity(i);
		}
	}

	private class FetchCategories extends AsyncTask<String, String, String> {
		
		@Override protected String doInBackground(String... params) {
			
			List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>();
			String[] POST_VALUES = { "function" };
        	for(int x = 0; x < params.length; x++) { nameValuePairs.add(new BasicNameValuePair(POST_VALUES[x], params[x])); }
			
			try {
				
				HttpClient httpClient = new DefaultHttpClient();
				HttpPost httpPost = new HttpPost("http://" + myServer.localhost() + "/eflier/api/eflier_api.php");
				httpPost.setEntity(new UrlEncodedFormEntity(nameValuePairs));
				HttpResponse httpResponse = httpClient.execute(httpPost);
				InputStream inputStream = httpResponse.getEntity().getContent();
				BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));
				StringBuilder sb = new StringBuilder(); String line = null;
				while((line = reader.readLine()) != null) { sb.append(line); }
				inputStream.close(); return sb.toString();
			}
			catch(Exception ex) { MessageBox("CONNECTION ERROR!"); }
			return null;
		}

		@Override protected void onPostExecute(String ResultSet) {
	
        	try {

        		List<String> data = new ArrayList<String>(); data.add("Choose Filter...");
        		JSONObject jsonObj = new JSONObject(ResultSet);
				JSONArray jsonArry = jsonObj.getJSONArray("Response");
				
				for(int x = 0; x < jsonArry.length(); x++)
				{
					JSONObject jsonResultSet = jsonArry.getJSONObject(x);
					Integer isValid = jsonResultSet.getInt("isValid");
					
					if(isValid.equals(1)) {
						       
						data.add(jsonResultSet.getString("Category"));
					}
				}
				
				ArrayAdapter<String> adapter = new ArrayAdapter<String>(getApplicationContext(), android.R.layout.simple_spinner_item, data);
		        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
		        CategorySpinner.setAdapter(adapter);
        	}
			catch(Exception ex) { MessageBox("JSON PARSING ERROR!"); }
		}
	}

	private class FetchDepartment extends AsyncTask<String, String, String> {
		
		@Override protected String doInBackground(String... params) {
			
			List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>();
			String[] POST_VALUES = { "department_id", "function" };
        	for(int x = 0; x < params.length; x++) { nameValuePairs.add(new BasicNameValuePair(POST_VALUES[x], params[x])); }
			
			try {
				
				HttpClient httpClient = new DefaultHttpClient();
				HttpPost httpPost = new HttpPost("http://" + myServer.localhost() + "/eflier/api/department_api.php");
				httpPost.setEntity(new UrlEncodedFormEntity(nameValuePairs));
				HttpResponse httpResponse = httpClient.execute(httpPost);
				InputStream inputStream = httpResponse.getEntity().getContent();
				BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));
				StringBuilder sb = new StringBuilder(); String line = null;
				while((line = reader.readLine()) != null) { sb.append(line); }
				inputStream.close(); return sb.toString();
			}
			catch(Exception ex) { MessageBox("CONNECTION ERROR!"); }
			return null;
		}

		@Override protected void onPostExecute(String ResultSet) {
	
        	try {

        		JSONObject jsonObj = new JSONObject(ResultSet);
				JSONArray jsonArry = jsonObj.getJSONArray("Response");
				JSONObject jsonResultSet = jsonArry.getJSONObject(0);
				Integer isValid = jsonResultSet.getInt("isValid");
				
				if(isValid.equals(1)) {
				
					myDepartment = new Department(jsonResultSet.getInt("DepartmentID"), jsonResultSet.getString("DepartmentName"), jsonResultSet.getString("Username"));
					new FetchEfliers().execute(String.valueOf(myDepartment.get_department_id()), "FETCH_EFLIERS_BY_DEPARTMENT");
				}
				else { MessageBox("DEPARTMENT DETAILS ERROR!"); }
			}
			catch(Exception ex) { MessageBox("JSON PARSING ERROR!"); }
		}
    }
	
	private void MessageBox(final String myMessage) {
	    
		runOnUiThread(new Runnable() {
			
			@Override public void run() {
				
				Toast.makeText(getApplicationContext(), myMessage, Toast.LENGTH_SHORT).show();
			}
		});
	}
}
