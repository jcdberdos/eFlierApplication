package com.example.eflier_admin;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.StringTokenizer;

import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONArray;
import org.json.JSONObject;

import com.example.models.Broadcast;
import com.example.models.Department;
import com.example.models.Server;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

@SuppressWarnings({"deprecation", "resource"})
public class BroadcastActivity extends Activity {

	private Server myServer = new Server();
	private Broadcast myBroadcast = null;
	private Department myDepartment = null;
	
	private Button SetStartButton, SetEndButton, BroadcastButton;
	private int[] DateID = { R.id.startdateText, R.id.enddateText };
	private int[] TimeID = { R.id.starttimeText, R.id.endtimeText };
	private String[] Months = { "JAN", "FEB", "MAR", "APR", "MAY", "JUN", "JUL", "AUG", "SEP", "OCT", "NOV", "DEC" };
	private TextView[] DateTV = new TextView[2];
	private TextView[] TimeTV = new TextView[2];
	private TimePicker BroadcastTP; private DatePicker BroadcastDP;
	
	@Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_broadcast);
      
        /* INSTANTIATE OBJECTS */
        for(int x = 0; x < DateTV.length; x++) { DateTV[x] = (TextView) findViewById(DateID[x]); }
		for(int x = 0; x < TimeTV.length; x++) { TimeTV[x] = (TextView) findViewById(TimeID[x]); }
        SetStartButton = (Button) findViewById(R.id.setstartButton);
        SetEndButton = (Button) findViewById(R.id.setendButton);
		BroadcastButton = (Button) findViewById(R.id.tm_broadcast_button);
        BroadcastTP = (TimePicker) findViewById(R.id.broadcastTime);
        BroadcastDP = (DatePicker) findViewById(R.id.broadcastDate);
        
        /* INSTANTIATE HANDLERS */
        ButtonHandler bh = new ButtonHandler();
        
        /* SET EVENT LISTENERS */
        SetStartButton.setOnClickListener(bh);
        SetEndButton.setOnClickListener(bh);
        BroadcastButton.setOnClickListener(bh);
        
        /* SET BROADCAST INFO */
        int myBroadcastID = getIntent().getExtras().getInt("eflier_id");
        int myDepartmentID = getIntent().getExtras().getInt("DepartmentID");
        myBroadcast = new Broadcast(myBroadcastID, null, null, null, null);
        myDepartment = new Department(myDepartmentID, null, null);
        new FetchBroadcast().execute(String.valueOf(myBroadcastID), "FETCH_BROADCAST");
        new FetchDepartment().execute(String.valueOf(myDepartmentID), "FETCH_DEPARTMENT");    
	}
	
	protected class ButtonHandler implements OnClickListener {

		@Override public void onClick(View v) {
			
			if (v.getId() == SetStartButton.getId()) {
				
				SetSchedule(0);
    		}
    		else if (v.getId() == SetEndButton.getId()) {
    			
    			SetSchedule(1);
    		}
    		else if(v.getId() == BroadcastButton.getId()) {
    			
    			if(!"".equals(DateTV[0].getText().toString()) && !"".equals(DateTV[1].getText().toString()) && !"".equals(TimeTV[0].getText().toString()) && !"".equals(TimeTV[1].getText().toString())) {
    				
    				String[] ScheduledDate = new String[2], ScheduledTime = new String[2];
    				int[] ScheduledMonth = new int[2], ScheduledDay = new int[2], ScheduledYear = new int[2];
    				
    				for(int x = 0; x < 2; x++) {
    				
    					StringTokenizer st = new StringTokenizer(DateTV[x].getText().toString(), " ,");
    					
    					ScheduledMonth[x] = Arrays.asList(Months).indexOf(st.nextToken()) + 1;
    					ScheduledDay[x] = Integer.parseInt(st.nextToken());
    					ScheduledYear[x] = Integer.parseInt(st.nextToken());
    					ScheduledDate[x] = ScheduledYear[x] + "-" + ScheduledMonth[x] + "-" + ScheduledDay[x];
    				}
    				
    				for(int x = 0; x < 2; x++) {
    				
    					try {
    						
    						SimpleDateFormat sdf = new SimpleDateFormat("hh:mm a");
            			    Date dateObj = sdf.parse(TimeTV[x].getText().toString());
            			    ScheduledTime[x] = new SimpleDateFormat("HH:mm").format(dateObj);
    					}
    					catch (Exception ex) { MessageBox("DATE/TIME FORMATTING ERROR"); }
    				}
    				
    				new UpdateBroadcastTask().execute(String.valueOf(myBroadcast.broadcast_id), ScheduledDate[0], ScheduledTime[0], ScheduledDate[1], ScheduledTime[1], "UPDATE_BROADCAST");
    			}
    			else {
    				
    				MessageBox("PLEASE SELECT DATE & TIME!");
    			}
    		}
        }
	}
	
	private void SetSchedule(int myIndex) {
		
		try {
		
			SimpleDateFormat sdf = new SimpleDateFormat("HH:mm");
		    Date dateObj = sdf.parse(BroadcastTP.getCurrentHour() + ":" + BroadcastTP.getCurrentMinute());
		    TimeTV[myIndex].setText(new SimpleDateFormat("hh:mm a").format(dateObj));
		    DateTV[myIndex].setText(Months[BroadcastDP.getMonth()] + " " + BroadcastDP.getDayOfMonth() + ", " + BroadcastDP.getYear());
		}
		catch (Exception ex) { MessageBox("DATE/TIME FORMATTING ERROR"); }
	}
	
	private class UpdateBroadcastTask extends AsyncTask<String, String, String> {

		private ProgressDialog myProgressDialog = null;
		
        @Override protected void onPreExecute() { myProgressDialog = ProgressDialog.show(BroadcastActivity.this, "UPDATING BROADCAST TIME!", "Please Wait..."); }

        @Override protected String doInBackground(String... params) {
            
        	List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>();
        	String[] POST_VALUES = { "broadcast_id", "bc_start_date", "bc_start_time", "bc_end_date", "bc_end_time", "function" };
        	for(int x = 0; x < params.length; x++) { nameValuePairs.add(new BasicNameValuePair(POST_VALUES[x], params[x])); }
        	
			try {
				
				HttpClient httpClient = new DefaultHttpClient();
				HttpPost httpPost = new HttpPost("http://" + myServer.localhost() + "/eflier/api/eflier_api.php");
				httpPost.setEntity(new UrlEncodedFormEntity(nameValuePairs));
				HttpResponse httpResponse = httpClient.execute(httpPost);
				InputStream inputStream = httpResponse.getEntity().getContent();
				BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));
				StringBuilder sb = new StringBuilder(); String line = null;
				while((line = reader.readLine()) != null) { sb.append(line); }
				inputStream.close(); return sb.toString();
			}
			catch(Exception ex) { MessageBox("CONNECTION ERROR!"); }
			return null;
        }
        
        @Override protected void onPostExecute(String ResultSet) {
            
        	try {

				JSONObject jsonObj = new JSONObject(ResultSet);
				JSONArray jsonArry = jsonObj.getJSONArray("Response");
				JSONObject jsonResultSet = jsonArry.getJSONObject(0);
				Integer isValid = jsonResultSet.getInt("isValid");
				myProgressDialog.dismiss();
				
				if(isValid.equals(1)) {
					
					MessageBox("SUCCESSFULLY UPDATED SCHEDULE!"); 
					Bundle b = new Bundle();
					b.putInt("DepartmentID", myDepartment.get_department_id());
					Intent i = new Intent(BroadcastActivity.this, DisseminateActivity.class);
					i.putExtras(b);
		    		startActivity(i);
				}
				else { MessageBox("FAILED TO UPDATE SCHEDULE!"); }
			} 
        	catch(Exception ex) { MessageBox("JSON PARSING ERROR!"); }
        }
    }
	
	private class FetchDepartment extends AsyncTask<String, String, String> {
		
		@Override protected String doInBackground(String... params) {
			
			List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>();
			String[] POST_VALUES = { "department_id", "function" };
        	for(int x = 0; x < params.length; x++) { nameValuePairs.add(new BasicNameValuePair(POST_VALUES[x], params[x])); }
			
			try {
				
				HttpClient httpClient = new DefaultHttpClient();
				HttpPost httpPost = new HttpPost("http://" + myServer.localhost() + "/eflier/api/department_api.php");
				httpPost.setEntity(new UrlEncodedFormEntity(nameValuePairs));
				HttpResponse httpResponse = httpClient.execute(httpPost);
				InputStream inputStream = httpResponse.getEntity().getContent();
				BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));
				StringBuilder sb = new StringBuilder(); String line = null;
				while((line = reader.readLine()) != null) { sb.append(line); }
				inputStream.close(); return sb.toString();
			}
			catch(Exception ex) { MessageBox("CONNECTION ERROR!"); }
			return null;
		}

		@Override protected void onPostExecute(String ResultSet) {
	
        	try {

        		JSONObject jsonObj = new JSONObject(ResultSet);
				JSONArray jsonArry = jsonObj.getJSONArray("Response");
				JSONObject jsonResultSet = jsonArry.getJSONObject(0);
				Integer isValid = jsonResultSet.getInt("isValid");
				
				if(isValid.equals(1)) {
				
					myDepartment = new Department(jsonResultSet.getInt("DepartmentID"), jsonResultSet.getString("DepartmentName"), jsonResultSet.getString("Username"));
					MessageBox("Welcome " + myDepartment.get_department_name() + "!");
				}
				else { MessageBox("DEPARTMENT DETAILS ERROR!"); }
			}
			catch(Exception ex) { MessageBox("JSON PARSING ERROR!"); }
		}
    }
	
	private class FetchBroadcast extends AsyncTask<String, String, String> {
		
		@Override protected String doInBackground(String... params) {
			
			List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>();
			String[] POST_VALUES = { "broadcast_id", "function" };
        	for(int x = 0; x < params.length; x++) { nameValuePairs.add(new BasicNameValuePair(POST_VALUES[x], params[x])); }
			
			try {
				
				HttpClient httpClient = new DefaultHttpClient();
				HttpPost httpPost = new HttpPost("http://" + myServer.localhost() + "/eflier/api/eflier_api.php");
				httpPost.setEntity(new UrlEncodedFormEntity(nameValuePairs));
				HttpResponse httpResponse = httpClient.execute(httpPost);
				InputStream inputStream = httpResponse.getEntity().getContent();
				BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));
				StringBuilder sb = new StringBuilder(); String line = null;
				while((line = reader.readLine()) != null) { sb.append(line); }
				inputStream.close(); return sb.toString();
			}
			catch(Exception ex) { MessageBox("CONNECTION ERROR!"); }
			return null;
		}

		@Override protected void onPostExecute(String ResultSet) {
	
        	try {

        		JSONObject jsonObj = new JSONObject(ResultSet);
				JSONArray jsonArry = jsonObj.getJSONArray("Response");
				JSONObject jsonResultSet = jsonArry.getJSONObject(0);
				Integer isValid = jsonResultSet.getInt("isValid");
				
				if(isValid.equals(1)) {
				
					myBroadcast = new Broadcast(jsonResultSet.getInt("BroadcastID"), jsonResultSet.getString("StartDate"), jsonResultSet.getString("StartTime"), jsonResultSet.getString("EndDate"), jsonResultSet.getString("EndTime"));
				
					String[] ScheduledDate = { myBroadcast.bc_start_date, myBroadcast.bc_end_date };
					String[] ScheduledTime = { myBroadcast.bc_start_time, myBroadcast.bc_end_time };
					String[] ScheduledMonth = new String[2];
					int[] ScheduledDay = new int[2], ScheduledYear = new int[2];
					
					for(int x = 0; x < DateTV.length; x++)
					{
						StringTokenizer st = new StringTokenizer(ScheduledDate[x], "-");
						ScheduledYear[x] = Integer.parseInt(st.nextToken());
						ScheduledMonth[x] = Months[Integer.parseInt(st.nextToken()) - 1];
    					ScheduledDay[x] = Integer.parseInt(st.nextToken());
    					DateTV[x].setText(ScheduledMonth[x] + " " + ScheduledDay[x] + ", " + ScheduledYear[x]);
					}
					
					for(int x = 0; x < TimeTV.length; x++)
					{
						SimpleDateFormat sdf = new SimpleDateFormat("HH:mm:ss");
					    Date dateObj = sdf.parse(ScheduledTime[x]);
					    TimeTV[x].setText(new SimpleDateFormat("hh:mm a").format(dateObj));
						
					}
				}
				else { MessageBox("BROADCAST DETAILS ERROR!"); }
			}
			catch(Exception ex) { MessageBox("JSON PARSING ERROR!"); }
		}
    }

	private void MessageBox(final String myMessage) {
	    
		runOnUiThread(new Runnable() {
			
			@Override public void run() {
				
				Toast.makeText(getApplicationContext(), myMessage, Toast.LENGTH_SHORT).show();
			}
		});
	}
}