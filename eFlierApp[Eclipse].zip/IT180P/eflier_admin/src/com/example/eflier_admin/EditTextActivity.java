package com.example.eflier_admin;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONArray;
import org.json.JSONObject;

import com.example.models.Department;
import com.example.models.Eflier;
import com.example.models.Server;
import com.example.models.Style;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Typeface;
import android.os.AsyncTask;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

@SuppressWarnings({"deprecation", "resource"})
public class EditTextActivity extends Activity {

	private Server myServer = new Server();
	private Department myDepartment = null;
	private Button UpdateButton;
	private TextView MessageSample;
	private EditText SubjectText, MessageText;
	private Spinner CategorySpinner;
	
	private TextView[] LabelTV = new TextView[5];
	private Typeface[] FontTypeface = new Typeface[3];
	private Button[] FontButtons = new Button[3], ColorButtons = new Button[6];
	private int[] FontArray = { R.id.et_regular_button, R.id.et_bold_button, R.id.et_italic_button }, ColorArray = { R.id.et_black_button, R.id.et_white_button, R.id.et_red_button, R.id.et_purple_button, R.id.et_blue_button, R.id.et_green_button }, LabelArray = { R.id.et_subject_textview, R.id.et_message_textview, R.id.et_word_textview, R.id.et_colors_textview, R.id.et_samplelayout_textview }, ColorResources = { R.color.black, R.color.white, R.color.red, R.color.purple, R.color.blue, R.color.green }, ColorReverse = { R.color.white, R.color.black, R.color.white, R.color.white, R.color.black, R.color.black }, Styles = { 0, 0 }, AllIDs = new int[2];
	private String[] TypefaceArray = { "Raleway-Regular.ttf", "Raleway-Bold.ttf", "Raleway-Italic.ttf" }, FontTextArray = { "REGULAR", "BOLD", "ITALIC" }, ColorTextArray = { "BLACK", "WHITE", "RED", "PURPLE", "BLUE", "GREEN" };
	
	@Override 
	protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edittext);
        
        /* INSTANTIATE OBJECTS */
        UpdateButton = (Button) findViewById(R.id.et_update_button);
        MessageSample = (TextView) findViewById(R.id.et_messagesample_textview);
        SubjectText = (EditText) findViewById(R.id.et_subject_textbox);
        MessageText = (EditText) findViewById(R.id.et_message_textbox);
        CategorySpinner = (Spinner) findViewById(R.id.et_category_spinner);
        for(int x = 0; x < FontButtons.length; x++) { FontButtons[x] = (Button) findViewById(FontArray[x]); FontButtons[x].setId(x); }
        for(int x = 0; x < ColorButtons.length; x++) { ColorButtons[x] = (Button) findViewById(ColorArray[x]); ColorButtons[x].setId(x); }
        for(int x = 0; x < LabelTV.length; x++) { LabelTV[x] = (TextView) findViewById(LabelArray[x]); }
        
        /* INSTANTIATE HANDLERS */
        ButtonHandler bh = new ButtonHandler();
        FontHandler fh = new FontHandler();
        ColorHandler ch = new ColorHandler();
        
        /* SET EVENT LISTENERS */
        UpdateButton.setOnClickListener(bh);
        MessageText.addTextChangedListener(new TextWatcher() { @Override public void onTextChanged(CharSequence s, int start, int before, int count) { MessageSample.setText(MessageText.getText().toString()); } @Override public void afterTextChanged(Editable arg0) { /* DO NOTHING HERE... */ } @Override public void beforeTextChanged(CharSequence arg0, int arg1, int arg2, int arg3) { /* DO NOTHING HERE... */ } });
        for(int x = 0; x < FontButtons.length; x++) { FontButtons[x].setOnClickListener(fh); }
        for(int x = 0; x < ColorButtons.length; x++) { ColorButtons[x].setOnClickListener(ch); }
        
        /* SET DEPARTMENT INFO */
        int myDepartmentID = getIntent().getExtras().getInt("DepartmentID");
        int myEflierID = getIntent().getExtras().getInt("eflier_id");
        myDepartment = new Department(myDepartmentID, null, null);
        new FetchDepartment().execute(String.valueOf(myDepartmentID), "FETCH_DEPARTMENT");
        new FetchCategories().execute("FETCH_CATEGORIES");
        new FetchEflier().execute(String.valueOf(myEflierID), "FETCH_EFLIER");
        
        /* SET FONT TYPEFACE */
        for(int x = 0; x < FontTypeface.length; x++) { FontTypeface[x] = Typeface.createFromAsset(getApplicationContext().getAssets(), TypefaceArray[x]); }  
        for(int x = 0; x < LabelTV.length; x++) { LabelTV[x].setTypeface(FontTypeface[0]); }
        MessageSample.setTypeface(FontTypeface[0]);
		UpdateButton.setTypeface(FontTypeface[1]);
		FontButtons[1].setTypeface(FontTypeface[1]);
        FontButtons[2].setTypeface(FontTypeface[2]);
	}

	private class ButtonHandler implements OnClickListener {

		@Override public void onClick(View v) {
    		
			if(v.getId() == UpdateButton.getId()) {
				
				if(!"".equals(SubjectText.getText().toString())) {
				
					if(!"".equals(MessageText.getText().toString())) {
						
						long CategoryID = CategorySpinner.getSelectedItemId() + 1;
						new UpdateAsyncTask().execute(String.valueOf(AllIDs[0]), SubjectText.getText().toString(), MessageText.getText().toString(), String.valueOf(myDepartment.get_department_id()), String.valueOf(CategoryID), String.valueOf(AllIDs[1]),FontTextArray[Styles[0]], ColorTextArray[Styles[1]], "UPDATE_TEXT");
					}
					else { MessageBox("ENTER EFLIER MESSAGE!"); }
				}
				else { MessageBox("ENTER SUBJECT MESSAGE!"); }
			}
        }
	}
	
	private class FontHandler implements OnClickListener { @Override public void onClick(View v) { int ButtonID = v.getId(); Styles[0] = ButtonID; MessageSample.setTypeface(FontTypeface[ButtonID]); MessageBox("FONT CHANGED TO " + FontTextArray[ButtonID] + "!"); } }
	
	private class ColorHandler implements OnClickListener { @Override public void onClick(View v) { int ButtonID = v.getId(); Styles[1] = ButtonID; MessageSample.setBackgroundResource(ColorResources[ButtonID]); MessageSample.setTextColor(getResources().getColor(ColorReverse[ButtonID])); MessageBox("COLOR THEME CHANGED TO " + ColorTextArray[ButtonID] + "!"); } }

	private class UpdateAsyncTask extends AsyncTask<String, String, String> {

		private ProgressDialog myProgressDialog = null;
		
        @Override protected void onPreExecute() { myProgressDialog = ProgressDialog.show(EditTextActivity.this, "UPDATING EFLIER!", "Please Wait..."); }
        
        @Override protected String doInBackground(String... params) {
            
        	List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>();
        	String[] POST_VALUES = { "eflier_id", "eflier_subject", "eflier_message", "department_id", "category_id", "styles_id", "font_style", "color_style", "function" };
        	for(int x = 0; x < params.length; x++) { nameValuePairs.add(new BasicNameValuePair(POST_VALUES[x], params[x])); }
        	
			try {
				
				HttpClient httpClient = new DefaultHttpClient();
				HttpPost httpPost = new HttpPost("http://" + myServer.localhost() + "/eflier/api/eflier_api.php");
				httpPost.setEntity(new UrlEncodedFormEntity(nameValuePairs));
				HttpResponse httpResponse = httpClient.execute(httpPost);
				InputStream inputStream = httpResponse.getEntity().getContent();
				BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));
				StringBuilder sb = new StringBuilder(); String line = null;
				while((line = reader.readLine()) != null) { sb.append(line); }
				inputStream.close(); return sb.toString();
			}
			catch(Exception ex) { MessageBox("CONNECTION ERROR!"); }
			return null;
        }
        
        @Override protected void onPostExecute(String ResultSet) {
        	
        	try {

				JSONObject jsonObj = new JSONObject(ResultSet);
				JSONArray jsonArry = jsonObj.getJSONArray("Response");
				JSONObject jsonResultSet = jsonArry.getJSONObject(0);
				Integer isValid = jsonResultSet.getInt("isValid");
				myProgressDialog.dismiss();
				
				if(isValid.equals(1)) {
					
					MessageBox("SUCCESSFULLY UPDATED EFLIER!"); 
					Bundle b = new Bundle();
					b.putInt("DepartmentID", myDepartment.get_department_id());
					Intent i = new Intent(EditTextActivity.this, DisseminateActivity.class);
					i.putExtras(b);
		    		startActivity(i);
				}
				else {
					
					MessageBox("FAILED TO UPDATE EFLIER!");
				}
			} 
        	catch(Exception ex) { MessageBox("JSON PARSING ERROR!"); }
        }
    }
    
	private class FetchCategories extends AsyncTask<String, String, String> {
		
		@Override protected String doInBackground(String... params) {
			
			List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>();
			String[] POST_VALUES = { "function" };
        	for(int x = 0; x < params.length; x++) { nameValuePairs.add(new BasicNameValuePair(POST_VALUES[x], params[x])); }
			
			try {
				
				HttpClient httpClient = new DefaultHttpClient();
				HttpPost httpPost = new HttpPost("http://" + myServer.localhost() + "/eflier/api/eflier_api.php");
				httpPost.setEntity(new UrlEncodedFormEntity(nameValuePairs));
				HttpResponse httpResponse = httpClient.execute(httpPost);
				InputStream inputStream = httpResponse.getEntity().getContent();
				BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));
				StringBuilder sb = new StringBuilder(); String line = null;
				while((line = reader.readLine()) != null) { sb.append(line); }
				inputStream.close(); return sb.toString();
			}
			catch(Exception ex) { MessageBox("CONNECTION ERROR!"); }
			return null;
		}

		@Override protected void onPostExecute(String ResultSet) {
	
        	try {

        		List<String> data = new ArrayList<String>();
        		JSONObject jsonObj = new JSONObject(ResultSet);
				JSONArray jsonArry = jsonObj.getJSONArray("Response");
				
				for(int x = 0; x < jsonArry.length(); x++)
				{
					JSONObject jsonResultSet = jsonArry.getJSONObject(x);
					Integer isValid = jsonResultSet.getInt("isValid");
					
					if(isValid.equals(1)) {
						       
						data.add(jsonResultSet.getString("Category"));
					}
				}
				
				ArrayAdapter<String> adapter = new ArrayAdapter<String>(getApplicationContext(), android.R.layout.simple_spinner_item, data);
		        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
		        CategorySpinner.setAdapter(adapter);
        	}
			catch(Exception ex) { MessageBox("JSON PARSING ERROR!"); }
		}
	}
	
	private class FetchEflier extends AsyncTask<String, String, String> {
		
		@Override protected String doInBackground(String... params) {
			
			List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>();
			String[] POST_VALUES = { "eflier_id", "function" };
        	for(int x = 0; x < params.length; x++) { nameValuePairs.add(new BasicNameValuePair(POST_VALUES[x], params[x])); }
        	
			try {
				
				HttpClient httpClient = new DefaultHttpClient();
				HttpPost httpPost = new HttpPost("http://" + myServer.localhost() + "/eflier/api/eflier_api.php");
				httpPost.setEntity(new UrlEncodedFormEntity(nameValuePairs));
				HttpResponse httpResponse = httpClient.execute(httpPost);
				InputStream inputStream = httpResponse.getEntity().getContent();
				BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));
				StringBuilder sb = new StringBuilder(); String line = null;
				while((line = reader.readLine()) != null) { sb.append(line); }
				inputStream.close(); return sb.toString();
			}
			catch(Exception ex) { MessageBox("CONNECTION ERROR!"); }
			return null;
		}

		@Override protected void onPostExecute(String ResultSet) {
	
        	try {

        		JSONObject jsonObj = new JSONObject(ResultSet);
	            JSONArray jsonArry = jsonObj.getJSONArray("Response");
	            JSONObject jsonResultSet = jsonArry.getJSONObject(0);
	            Integer isValid = jsonResultSet.getInt("isValid");
				
				if(isValid.equals(1)) {
				
					Eflier myEflier = new Eflier(jsonResultSet.getInt("eflier_id"), jsonResultSet.getString("eflier_subject"), jsonResultSet.getString("eflier_message"), jsonResultSet.getString("image_file"), jsonResultSet.getInt("department_id"), jsonResultSet.getInt("category_id"), jsonResultSet.getInt("styles_id"), jsonResultSet.getInt("broadcast_id"), jsonResultSet.getString("date_uploaded"));
					Style myStyle = new Style(jsonResultSet.getInt("styles_id"), jsonResultSet.getString("font_style"), jsonResultSet.getString("color_style"));
					SetData(myEflier, myStyle);
				}
			}
			catch(Exception ex) { MessageBox("ERROR RETRIEVING DATA!"); }
		}
    }
	
	private void SetData(Eflier myEflier, Style myStyle)
	{
		SubjectText.setText(myEflier.eflier_subject);
		MessageText.setText(myEflier.eflier_message);
		MessageSample.setText(myEflier.eflier_message);
		
		List<String> newFontArray = Arrays.asList(FontTextArray);
		List<String> newColorArray = Arrays.asList(ColorTextArray);
		
		Styles[0] = newFontArray.indexOf(myStyle.font_style);
		Styles[1] = newColorArray.indexOf(myStyle.color_style);
		
		MessageSample.setTypeface(FontTypeface[Styles[0]]);
		MessageSample.setBackgroundResource(ColorResources[Styles[1]]); 
		MessageSample.setTextColor(getResources().getColor(ColorReverse[Styles[1]]));
		CategorySpinner.setSelection(myEflier.category_id - 1);
	
		AllIDs[0] = myEflier.eflier_id;
		AllIDs[1] = myStyle.styles_id;
	}

	private class FetchDepartment extends AsyncTask<String, String, String> {
		
		@Override protected String doInBackground(String... params) {
			
			List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>();
			String[] POST_VALUES = { "department_id", "function" };
        	for(int x = 0; x < params.length; x++) { nameValuePairs.add(new BasicNameValuePair(POST_VALUES[x], params[x])); }
			
			try {
				
				HttpClient httpClient = new DefaultHttpClient();
				HttpPost httpPost = new HttpPost("http://" + myServer.localhost() + "/eflier/api/department_api.php");
				httpPost.setEntity(new UrlEncodedFormEntity(nameValuePairs));
				HttpResponse httpResponse = httpClient.execute(httpPost);
				InputStream inputStream = httpResponse.getEntity().getContent();
				BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));
				StringBuilder sb = new StringBuilder(); String line = null;
				while((line = reader.readLine()) != null) { sb.append(line); }
				inputStream.close(); return sb.toString();
			}
			catch(Exception ex) { MessageBox("CONNECTION ERROR!"); }
			return null;
		}

		@Override protected void onPostExecute(String ResultSet) {
	
        	try {

        		JSONObject jsonObj = new JSONObject(ResultSet);
				JSONArray jsonArry = jsonObj.getJSONArray("Response");
				JSONObject jsonResultSet = jsonArry.getJSONObject(0);
				Integer isValid = jsonResultSet.getInt("isValid");
				
				if(isValid.equals(1)) {
				
					myDepartment = new Department(jsonResultSet.getInt("DepartmentID"), jsonResultSet.getString("DepartmentName"), jsonResultSet.getString("Username"));
				}
				else { MessageBox("DEPARTMENT DETAILS ERROR!"); }
			}
			catch(Exception ex) { MessageBox("JSON PARSING ERROR!"); }
		}
    }
	
	private void MessageBox(final String myMessage) {
	    
		runOnUiThread(new Runnable() {
			
			@Override public void run() {
				
				Toast.makeText(getApplicationContext(), myMessage, Toast.LENGTH_SHORT).show();
			}
		});
	}
}