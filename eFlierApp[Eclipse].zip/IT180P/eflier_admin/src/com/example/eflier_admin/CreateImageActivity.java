package com.example.eflier_admin;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONArray;
import org.json.JSONObject;

import com.example.models.Department;
import com.example.models.Server;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Typeface;
import android.graphics.drawable.BitmapDrawable;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Base64;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

@SuppressWarnings({"deprecation", "resource"})
public class CreateImageActivity extends Activity {

	private Server myServer = new Server();
	private Department myDepartment = null;
	private Button ChooseButton, CreateButton;
	private ImageView myImageView = null;
	private TextView SubjectLabel;
	private EditText SubjectText;
	private Spinner CategorySpinner;
	
	@Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_createimage);
      
        /* INSTANTIATE OBJECTS */
        ChooseButton = (Button) findViewById(R.id.ue_choose_button);
        CreateButton = (Button) findViewById(R.id.ue_create_button);
        SubjectLabel = (TextView) findViewById(R.id.ue_subject_textview);
        SubjectText = (EditText) findViewById(R.id.ue_subject_textbox);
        myImageView = (ImageView) findViewById(R.id.ue_eflier_image);
        CategorySpinner = (Spinner) findViewById(R.id.category_spinner_1);
        
        /* INSTANTIATE HANDLERS */
        ButtonHandler bh = new ButtonHandler();
        
        /* SET EVENT LISTENERS */
        ChooseButton.setOnClickListener(bh);
        CreateButton.setOnClickListener(bh);
        
        /* SET DEPARTMENT INFO */
        int myDepartmentID = getIntent().getExtras().getInt("DepartmentID");
        myDepartment = new Department(myDepartmentID, null, null);
        new FetchDepartment().execute(String.valueOf(myDepartmentID), "FETCH_DEPARTMENT");
        new FetchCategories().execute("FETCH_CATEGORIES");
        
        /* SET FONT TYPEFACE */
        Typeface regular = Typeface.createFromAsset(getApplicationContext().getAssets(), "Raleway-Regular.ttf"), boldfont = Typeface.createFromAsset(getApplicationContext().getAssets(), "Raleway-Bold.ttf");
        SubjectLabel.setTypeface(regular);
        ChooseButton.setTypeface(boldfont);
        CreateButton.setTypeface(boldfont);
	}
	
	private class ButtonHandler implements OnClickListener {

		@Override
    	public void onClick(View v) {
    		
			if (v.getId() == ChooseButton.getId()) {
				
				Intent myIntent = new Intent();
				myIntent.setType("image/*");
				myIntent.setAction(Intent.ACTION_GET_CONTENT);
                startActivityForResult(Intent.createChooser(myIntent, "Choose Image"), 1);
			}
			else if(v.getId() == CreateButton.getId()) {
				
				if(!"".equals(SubjectText.getText().toString())) {
				
					if(myImageView.getDrawable() != null) {
						
						long CategoryID = CategorySpinner.getSelectedItemId() + 1;
			        	new ImageAsyncTask().execute(SubjectText.getText().toString(), ConvertedImage(myImageView), String.valueOf(myDepartment.get_department_id()), String.valueOf(CategoryID), "CREATE_IMAGE");
					}
					else { MessageBox("PLEASE CHOOSE IMAGE!"); }
				}
				else { MessageBox("ENTER SUBJECT MESSAGE!"); }
			}
        }
	}
	
	@Override
    protected void onActivityResult(int RC, int RQC, Intent myIntent) {
        super.onActivityResult(RC, RQC, myIntent);
 
        if (RC == 1 && RQC == RESULT_OK && myIntent != null && myIntent.getData() != null) {
       	
        	Uri myUri = myIntent.getData();
        	
            try {
            	
            	myImageView.setImageBitmap(MediaStore.Images.Media.getBitmap(getContentResolver(), myUri));
            } 
            catch (Exception ex) {

            	MessageBox("IMAGE FORMAT UNSUPPORTED!");
            }
        }
    }
	
	private String ConvertedImage(ImageView imageView) {
		
		BitmapDrawable drawable = (BitmapDrawable) imageView.getDrawable();
    	Bitmap bitmap = drawable.getBitmap();
    	ByteArrayOutputStream myByteArrayOutputStream = new ByteArrayOutputStream();  
    	bitmap.compress(Bitmap.CompressFormat.PNG, 100, myByteArrayOutputStream); 
    	byte[] byteArrayVar = myByteArrayOutputStream.toByteArray();
    	return Base64.encodeToString(byteArrayVar, Base64.DEFAULT);
	}

	private class ImageAsyncTask extends AsyncTask<String, String, String> {

		private ProgressDialog myProgressDialog = null;
		
        @Override protected void onPreExecute() { myProgressDialog = ProgressDialog.show(CreateImageActivity.this, "CREATING EFLIER!", "Please wait..."); }

        @Override protected String doInBackground(String... params) {
            
        	List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>();
        	String[] POST_VALUES = { "eflier_subject", "image_file", "department_id", "category_id", "function" };
        	for(int x = 0; x < params.length; x++) { nameValuePairs.add(new BasicNameValuePair(POST_VALUES[x], params[x])); }
        	
			try {
				
				HttpClient httpClient = new DefaultHttpClient();
				HttpPost httpPost = new HttpPost("http://" + myServer.localhost() + "/eflier/api/eflier_api.php");
				httpPost.setEntity(new UrlEncodedFormEntity(nameValuePairs));
				HttpResponse httpResponse = httpClient.execute(httpPost);
				InputStream inputStream = httpResponse.getEntity().getContent();
				BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));
				StringBuilder sb = new StringBuilder(); String line = null;
				while((line = reader.readLine()) != null) { sb.append(line); }
				inputStream.close(); return sb.toString();
			}
			catch(Exception ex) { MessageBox("CONNECTION ERROR!"); }
			return null;
        }
        
        @Override protected void onPostExecute(String ResultSet) {
            
        	try {

				JSONObject jsonObj = new JSONObject(ResultSet);
				JSONArray jsonArry = jsonObj.getJSONArray("Response");
				JSONObject jsonResultSet = jsonArry.getJSONObject(0);
				Integer isValid = jsonResultSet.getInt("isValid");
				myProgressDialog.dismiss();
				
				if(isValid.equals(1)) {
					
					MessageBox("SUCCESSFULLY CREATED EFLIER!"); 
					finish();
				}
				else {
					
					MessageBox("FAILED TO CREATE EFLIER!");
				}
			} 
        	catch(Exception ex) { MessageBox("JSON PARSING ERROR!"); }
        }
    }
	
	private class FetchCategories extends AsyncTask<String, String, String> {
		
		@Override protected String doInBackground(String... params) {
			
			List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>();
			String[] POST_VALUES = { "function" };
        	for(int x = 0; x < params.length; x++) { nameValuePairs.add(new BasicNameValuePair(POST_VALUES[x], params[x])); }
			
			try {
				
				HttpClient httpClient = new DefaultHttpClient();
				HttpPost httpPost = new HttpPost("http://" + myServer.localhost() + "/eflier/api/eflier_api.php");
				httpPost.setEntity(new UrlEncodedFormEntity(nameValuePairs));
				HttpResponse httpResponse = httpClient.execute(httpPost);
				InputStream inputStream = httpResponse.getEntity().getContent();
				BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));
				StringBuilder sb = new StringBuilder(); String line = null;
				while((line = reader.readLine()) != null) { sb.append(line); }
				inputStream.close(); return sb.toString();
			}
			catch(Exception ex) { MessageBox("CONNECTION ERROR!"); }
			return null;
		}

		@Override protected void onPostExecute(String ResultSet) {
	
        	try {

        		List<String> data = new ArrayList<String>();
        		JSONObject jsonObj = new JSONObject(ResultSet);
				JSONArray jsonArry = jsonObj.getJSONArray("Response");
				
				for(int x = 0; x < jsonArry.length(); x++)
				{
					JSONObject jsonResultSet = jsonArry.getJSONObject(x);
					Integer isValid = jsonResultSet.getInt("isValid");
					
					if(isValid.equals(1)) {
						       
						data.add(jsonResultSet.getString("Category"));
					}
				}
				
				ArrayAdapter<String> adapter = new ArrayAdapter<String>(getApplicationContext(), android.R.layout.simple_spinner_item, data);
		        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
		        CategorySpinner.setAdapter(adapter);
        	}
			catch(Exception ex) { MessageBox("JSON PARSING ERROR!"); }
		}
	}

	private class FetchDepartment extends AsyncTask<String, String, String> {
		
		@Override protected String doInBackground(String... params) {
			
			List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>();
			String[] POST_VALUES = { "department_id", "function" };
        	for(int x = 0; x < params.length; x++) { nameValuePairs.add(new BasicNameValuePair(POST_VALUES[x], params[x])); }
			
			try {
				
				HttpClient httpClient = new DefaultHttpClient();
				HttpPost httpPost = new HttpPost("http://" + myServer.localhost() + "/eflier/api/department_api.php");
				httpPost.setEntity(new UrlEncodedFormEntity(nameValuePairs));
				HttpResponse httpResponse = httpClient.execute(httpPost);
				InputStream inputStream = httpResponse.getEntity().getContent();
				BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));
				StringBuilder sb = new StringBuilder(); String line = null;
				while((line = reader.readLine()) != null) { sb.append(line); }
				inputStream.close(); return sb.toString();
			}
			catch(Exception ex) { MessageBox("CONNECTION ERROR!"); }
			return null;
		}

		@Override protected void onPostExecute(String ResultSet) {
	
        	try {

        		JSONObject jsonObj = new JSONObject(ResultSet);
				JSONArray jsonArry = jsonObj.getJSONArray("Response");
				JSONObject jsonResultSet = jsonArry.getJSONObject(0);
				Integer isValid = jsonResultSet.getInt("isValid");
				
				if(isValid.equals(1)) {
				
					myDepartment = new Department(jsonResultSet.getInt("DepartmentID"), jsonResultSet.getString("DepartmentName"), jsonResultSet.getString("Username"));
				}
				else { MessageBox("DEPARTMENT DETAILS ERROR!"); }
			}
			catch(Exception ex) { MessageBox("JSON PARSING ERROR!"); }
		}
    }
	
	private void MessageBox(final String myMessage) {
	    
		runOnUiThread(new Runnable() {
			
			@Override public void run() {
				
				Toast.makeText(getApplicationContext(), myMessage, Toast.LENGTH_SHORT).show();
			}
		});
	}
}