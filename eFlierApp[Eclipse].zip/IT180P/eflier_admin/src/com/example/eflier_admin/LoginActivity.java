package com.example.eflier_admin;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONArray;
import org.json.JSONObject;

import com.example.models.Server;

import android.app.Activity;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

@SuppressWarnings({"deprecation", "resource"})
public class LoginActivity extends Activity {

	private Server myServer = new Server();
	private EditText UsernameText, PasswordText;
	private Button LoginButton;
	
	@Override 
	protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        /* INSTANTIATE OBJECTS */
		UsernameText = (EditText) findViewById(R.id.lg_username_textbox);
        PasswordText = (EditText) findViewById(R.id.lg_password_textbox);
        LoginButton = (Button) findViewById(R.id.lg_login_button);
        
        /* INSTANTIATE HANDLERS */
		ButtonHandler bh = new ButtonHandler();
		
        /* SET EVENT LISTENERS */
        LoginButton.setOnClickListener(bh);
	}
		
	private class ButtonHandler implements OnClickListener {
    	
		@Override public void onClick(View v) {
    			
    		if (v.getId() == LoginButton.getId()) {
    
    			if(!"".equals(UsernameText.getText().toString()) && !"".equals(PasswordText.getText().toString())) {
    				
    				new LoginTask().execute(UsernameText.getText().toString(), PasswordText.getText().toString(), "LOGIN");
    			}
    			else {
    				
    				MessageBox("FILL IN ALL FIELDS!");
    			}
    		}
		}
	}
	
	private class LoginTask extends AsyncTask<String, String, String> {
		
		@Override protected String doInBackground(String... params) {
			
			List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>();
			String[] POST_VALUES = { "_username", "_password", "function" };
        	for(int x = 0; x < params.length; x++) { nameValuePairs.add(new BasicNameValuePair(POST_VALUES[x], params[x])); }
		
			try {
				
				HttpClient httpClient = new DefaultHttpClient();
				HttpPost httpPost = new HttpPost("http://" + myServer.localhost() + "/eflier/api/department_api.php");
				httpPost.setEntity(new UrlEncodedFormEntity(nameValuePairs));
				HttpResponse httpResponse = httpClient.execute(httpPost);
				InputStream inputStream = httpResponse.getEntity().getContent();
				BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));
				StringBuilder sb = new StringBuilder(); String line = null;
				while((line = reader.readLine()) != null) { sb.append(line); }
				inputStream.close(); return sb.toString();
			} 
			catch(Exception ex) { MessageBox("CONNECTION ERROR!"); }
			return null;
		}

		@Override protected void onPostExecute(String ResultSet) {
	
        	try {

				JSONObject jsonObj = new JSONObject(ResultSet);
				JSONArray jsonArry = jsonObj.getJSONArray("Response");
				JSONObject jsonResultSet = jsonArry.getJSONObject(0);
				Integer isValid = jsonResultSet.getInt("isValid");
				
				if(isValid.equals(1)) {
				
					final int myDepartmentID = jsonResultSet.getInt("DepartmentID");
					
					runOnUiThread(new Runnable() { @Override public void run() { 

		            	Bundle b = new Bundle();
						b.putInt("DepartmentID", myDepartmentID);
						Intent i = new Intent(LoginActivity.this, MainActivity.class);
						i.putExtras(b);
						startActivity(i);
					}});
				}
				else { MessageBox("INVALID ACCOUNT DETAILS!"); }
			}
        	catch(Exception ex) { MessageBox("JSON PARSING ERROR!"); }
		}
    }
	
	private void MessageBox(final String myMessage) {
	    
		runOnUiThread(new Runnable() {
			
			@Override public void run() {
				
				Toast.makeText(getApplicationContext(), myMessage, Toast.LENGTH_SHORT).show();
			}
		});
	}
}