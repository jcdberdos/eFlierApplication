package com.example.eflier_admin;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONArray;
import org.json.JSONObject;

import com.example.models.Department;
import com.example.models.Server;

import android.app.Activity;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.TableRow;
import android.widget.Toast;

@SuppressWarnings({"deprecation", "resource"})
public class MainActivity extends Activity {

	private Server myServer = new Server();
	private Department myDepartment = null;
	private TableRow[] myButtons = new TableRow[3];
	private int[] myButtonID = { R.id.mm_disseminatelayout, R.id.upload_row, R.id.type_row };
	
    @Override 
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        
        /* INSTANTIATE OBJECTS */
    	for(int x = 0; x < myButtons.length; x++) { myButtons[x] = (TableRow) findViewById(myButtonID[x]); myButtons[x].setId(x); }
    	
        /* INSTANTIATE HANDLERS */
    	ButtonHandler bh = new ButtonHandler();	
        
        /* SET EVENT LISTENERS */
    	for(int x = 0; x < myButtons.length; x++) { myButtons[x].setOnClickListener(bh); }
        
    	/* SET DEPARTMENT INFO */
        int myDepartmentID = getIntent().getExtras().getInt("DepartmentID");
        myDepartment = new Department(myDepartmentID, null, null);
        new FetchDepartment().execute(String.valueOf(myDepartmentID), "FETCH_DEPARTMENT");
    }
    
    private class ButtonHandler implements OnClickListener {
    	
		@Override public void onClick(View v) {
			
			Bundle b = new Bundle();
			b.putInt("DepartmentID", myDepartment.get_department_id());
			Intent i = null;
			
			switch(v.getId()) {
			
				case 0: i = new Intent(MainActivity.this, DisseminateActivity.class); break;
				case 1: i = new Intent(MainActivity.this, CreateImageActivity.class); break;
				case 2: i = new Intent(MainActivity.this, CreateTextActivity.class); break;
			}
			
    		i.putExtras(b);
    		startActivity(i);
        }
	}

    private class FetchDepartment extends AsyncTask<String, String, String> {
			
		@Override protected String doInBackground(String... params) {
			
			List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>();
			String[] POST_VALUES = { "department_id", "function" };
        	for(int x = 0; x < params.length; x++) { nameValuePairs.add(new BasicNameValuePair(POST_VALUES[x], params[x])); }
			
			try {
				
				HttpClient httpClient = new DefaultHttpClient();
				HttpPost httpPost = new HttpPost("http://" + myServer.localhost() + "/eflier/api/department_api.php");
				httpPost.setEntity(new UrlEncodedFormEntity(nameValuePairs));
				HttpResponse httpResponse = httpClient.execute(httpPost);
				InputStream inputStream = httpResponse.getEntity().getContent();
				BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));
				StringBuilder sb = new StringBuilder(); String line = null;
				while((line = reader.readLine()) != null) { sb.append(line); }
				inputStream.close(); return sb.toString();
			}
			catch(Exception ex) { MessageBox("CONNECTION ERROR!"); }
			return null;
		}

		@Override protected void onPostExecute(String ResultSet) {
	
        	try {

        		JSONObject jsonObj = new JSONObject(ResultSet);
				JSONArray jsonArry = jsonObj.getJSONArray("Response");
				JSONObject jsonResultSet = jsonArry.getJSONObject(0);
				Integer isValid = jsonResultSet.getInt("isValid");
				
				if(isValid.equals(1)) {
				
					myDepartment = new Department(jsonResultSet.getInt("DepartmentID"), jsonResultSet.getString("DepartmentName"), jsonResultSet.getString("Username"));
					MessageBox("Welcome " + myDepartment.get_department_name() + "!");
				}
				else { MessageBox("DEPARTMENT DETAILS ERROR!"); }
			}
			catch(Exception ex) { MessageBox("JSON PARSING ERROR!"); }
		}
    }
    
    private void MessageBox(final String myMessage) {
	    
		runOnUiThread(new Runnable() {
			
			@Override public void run() {
				
				Toast.makeText(getApplicationContext(), myMessage, Toast.LENGTH_SHORT).show();
			}
		});
	}
}