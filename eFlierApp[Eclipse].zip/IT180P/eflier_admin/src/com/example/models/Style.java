package com.example.models;

public class Style {

	public int styles_id = 0;
	public String font_style = null, color_style = null;
    
    public Style(int styles_id, String font_style, String color_style) {
    	
    	this.styles_id = styles_id;
    	this.font_style = font_style; 
    	this.color_style = color_style;
    }
}