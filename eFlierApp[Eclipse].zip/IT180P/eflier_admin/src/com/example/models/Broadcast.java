package com.example.models;

public class Broadcast {

	public int broadcast_id = 0;
	public String bc_start_date = null, bc_start_time = null, bc_end_date = null, bc_end_time = null;
    
    public Broadcast(int broadcast_id, String bc_start_date, String bc_start_time, String bc_end_date, String bc_end_time) {
    	
    	this.broadcast_id = broadcast_id;
    	this.bc_start_date = bc_start_date; 
    	this.bc_start_time = bc_start_time; 
    	this.bc_end_date = bc_end_date;
    	this.bc_end_time = bc_end_time;
    }
}