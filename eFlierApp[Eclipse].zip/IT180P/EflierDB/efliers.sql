-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Dec 11, 2017 at 11:34 AM
-- Server version: 10.1.13-MariaDB
-- PHP Version: 5.5.34

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `eflier`
--

-- --------------------------------------------------------

--
-- Table structure for table `efliers`
--

CREATE TABLE `efliers` (
  `eflier_id` int(11) NOT NULL,
  `eflier_subject` varchar(24) NOT NULL,
  `eflier_message` text NOT NULL,
  `image_file` varchar(24) NOT NULL,
  `department_id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  `styles_id` int(11) NOT NULL,
  `broadcast_id` int(11) NOT NULL,
  `date_uploaded` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `efliers`
--

INSERT INTO `efliers` (`eflier_id`, `eflier_subject`, `eflier_message`, `image_file`, `department_id`, `category_id`, `styles_id`, `broadcast_id`, `date_uploaded`) VALUES
(39, 'sample message', 'hello world!', 'null', 1, 3, 40, 40, '2017-12-11'),
(41, 'another sample', 'this is another sample message hehehe.', 'null', 1, 1, 42, 42, '2017-12-11'),
(42, 'sample text', 'this is a sample message', 'null', 1, 1, 43, 43, '2017-12-11'),
(44, 'JISSA MCL', 'null', 'IMG-44.PNG', 1, 1, 45, 45, '2017-12-11'),
(45, 'sampol', 'null', 'IMG-45.PNG', 1, 2, 46, 46, '2017-12-11'),
(46, 'sampol', 'sampol 321123', 'null', 1, 1, 47, 47, '2017-12-11'),
(47, 'hhh', 'hjhghh', 'null', 1, 5, 48, 48, '2017-12-11'),
(48, 'Finals Week', 'study hard bro', 'null', 1, 1, 49, 49, '2017-12-11'),
(49, 'testing', 'null', 'IMG-49.PNG', 1, 1, 50, 50, '2017-12-11');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `efliers`
--
ALTER TABLE `efliers`
  ADD PRIMARY KEY (`eflier_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `efliers`
--
ALTER TABLE `efliers`
  MODIFY `eflier_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=50;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
