package com.application.beartoast.eflier_patron.Activities;

/**
 * Created by JSabino on 12 Feb 2018.
 */

public class Server {
    private String _localhost = "192.168.43.91";

    public String localhost() {

        return this._localhost;
    }
}
