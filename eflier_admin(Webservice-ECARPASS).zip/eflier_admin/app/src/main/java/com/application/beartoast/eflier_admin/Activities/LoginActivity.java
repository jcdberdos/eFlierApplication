package com.application.beartoast.eflier_admin.Activities;

import android.content.Intent;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Message;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.application.beartoast.eflier_admin.R;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;

@SuppressWarnings({"deprecation", "resource"})
public class LoginActivity extends AppCompatActivity {

    EditText UsernameText, PasswordText;
    Button LoginButton;

    Server myServer = new Server();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        UsernameText = (EditText) findViewById(R.id.lg_username_textbox);
        PasswordText = (EditText) findViewById(R.id.lg_password_textbox);
        LoginButton = (Button) findViewById(R.id.lg_login_button);

        /* INSTANTIATE HANDLERS */
        ButtonHandler bh = new ButtonHandler();

        /* SET EVENT LISTENERS */
        LoginButton.setOnClickListener(bh);

        UsernameText.requestFocus();
    }

    private class ButtonHandler implements View.OnClickListener {
        @Override
        public void onClick(View v) {
            if (v.getId() == LoginButton.getId()) {

                if (!"".equals(UsernameText.getText().toString()) && !"".equals(PasswordText.getText().toString())) {

                    new LoginTask().execute(UsernameText.getText().toString(), PasswordText.getText().toString(), "LOGIN");
                }
                else {

                    MessageBox("FILL IN ALL FIELDS!");
                }
            }
        }
    }

    private void MessageBox(final String myMessage) {

        runOnUiThread(new Runnable() {

            @Override
            public void run() {

                Toast.makeText(getApplicationContext(), myMessage, Toast.LENGTH_SHORT).show();
            }
        });
    }

    private class LoginTask extends AsyncTask<String, String, String> {

        @Override
        protected void onPreExecute() {

            super.onPreExecute();
        }

        @Override
        protected String doInBackground(String... params) {

            try {

                URL myURL = new URL("http://" + myServer.localhost() + "/eflier/api/department_api.php");
                HttpURLConnection c = (HttpURLConnection) myURL.openConnection();
                c.setReadTimeout(15000);
                c.setConnectTimeout(10000);
                c.setRequestMethod("POST");
                c.setDoInput(true);
                c.setDoOutput(true);

                String[] POST_VALUES = { "_username", "_password", "function" };
                Uri.Builder b = new Uri.Builder();
                for(int x = 0; x < params.length; x++)
                {
                    b.appendQueryParameter(POST_VALUES[x], params[x]);
                }

                String q = b.build().getEncodedQuery();
                OutputStream os = c.getOutputStream();

                MessageBox("HELLO");

                BufferedWriter w = new BufferedWriter(new OutputStreamWriter(os, "UTF-8"));
                w.write(q);
                w.flush();
                w.close();
                os.close();
                c.connect();


                if(c.getResponseCode() == HttpURLConnection.HTTP_OK) {

                    MessageBox("HELLO");
                    BufferedReader reader = new BufferedReader(new InputStreamReader(c.getInputStream()));
                    StringBuilder sb = new StringBuilder(); String line = null;
                    while ((line = reader.readLine()) != null) { sb.append(line); }

                    return sb.toString();
                }
                else {

                    MessageBox("MAY MALI SA HTTP");
                }

                c.disconnect();
            }
            catch (Exception ex) {

                MessageBox("MAY NA CATCH");
            }

            return null;
        }

        @Override protected void onPostExecute(String ResultSet) {


            //Toast.makeText(LoginActivity.this, ResultSet, Toast.LENGTH_SHORT).show();
            MessageBox(ResultSet + "hkjhj");
            /*

            try {

                JSONObject jsonObj = new JSONObject(ResultSet);
                JSONArray jsonArry = jsonObj.getJSONArray("Response");
                JSONObject jsonResultSet = jsonArry.getJSONObject(0);
                Integer isValid = jsonResultSet.getInt("isValid");

                if(isValid.equals(1)) {

                    final int myDepartmentID = jsonResultSet.getInt("DepartmentID");

                    runOnUiThread(new Runnable() { @Override public void run() {

                        Bundle b = new Bundle();
                        b.putInt("DepartmentID", myDepartmentID);
                        Intent i = new Intent(LoginActivity.this, MainMenuActivity.class);
                        i.putExtras(b);
                        startActivity(i);
                        LoginActivity.this.finish();
                    }});
                }
                else { MessageBox("INVALID ACCOUNT DETAILS!"); }
            }
            catch(Exception ex) { MessageBox("JSON PARSING ERROR!"); }

            */
        }
    }

}