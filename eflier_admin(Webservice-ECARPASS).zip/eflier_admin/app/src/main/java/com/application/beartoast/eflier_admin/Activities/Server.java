package com.application.beartoast.eflier_admin.Activities;

/**
 * Created by JSabino on 2 Feb 2018.
 */

public class Server {

    private String _localhost = "192.168.1.149";

    public String localhost() {

        return this._localhost;
    }
}
