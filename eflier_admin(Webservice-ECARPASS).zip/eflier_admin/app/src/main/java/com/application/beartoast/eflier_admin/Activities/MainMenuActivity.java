package com.application.beartoast.eflier_admin.Activities;

import android.app.Fragment;
import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.view.View;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.application.beartoast.eflier_admin.Fragments.CreateImageFragment;
import com.application.beartoast.eflier_admin.Fragments.DisseminateFragment;
import com.application.beartoast.eflier_admin.Fragments.TypeMessageFragment;
import com.application.beartoast.eflier_admin.R;

import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

public class MainMenuActivity extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener {

    private LinearLayout Content_Container;
    private Server myServer = new Server();
    private Department myDepartment = null;
    private boolean exit = false;
    private TextView AnalyticsNumber;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_menu);

        Content_Container = (LinearLayout) findViewById(R.id.content_container);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.setDrawerListener(toggle);
        toggle.syncState();

        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);
    }

    @Override
    public void onBackPressed() {
        if (exit) {
            finish(); // finish activity
        } else {
            Toast.makeText(this, "Press Back again to Exit.",
                    Toast.LENGTH_SHORT).show();
            exit = true;
            new Handler().postDelayed(new Runnable() {
                @Override
                public void run() {
                    exit = false;
                }
            }, 3 * 1000);
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main_menu, menu);
        return true;
    }

    /**@Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }**/

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.

        FragmentManager fragmentManager = getFragmentManager ();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction ();

        Bundle b = new Bundle();
        b.putInt("DepartmentID", myDepartment.get_department_id());
        int id = item.getItemId();


        if (id == R.id.nav_uploadimage) {
            Content_Container.removeAllViewsInLayout();
            CreateImageFragment createimage = new CreateImageFragment();
            createimage.setArguments(b);
            fragmentTransaction.add (R.id.content_container, createimage, "1");
            fragmentTransaction.commit ();

        }

        else if (id == R.id.nav_typemsg) {
            Content_Container.removeAllViewsInLayout();
            TypeMessageFragment typemsg = new TypeMessageFragment();
            typemsg.setArguments(b);
            fragmentTransaction.add (R.id.content_container, typemsg, "2");
            fragmentTransaction.commit ();

        }

        else if (id == R.id.nav_disseminate) {
            Content_Container.removeAllViewsInLayout();
            DisseminateFragment disseminate = new DisseminateFragment();
            disseminate.setArguments(b);
            fragmentTransaction.add (R.id.content_container, disseminate, "3");
            fragmentTransaction.commit ();
        }

        else if (id == R.id.nav_home) {
            Content_Container.removeAllViewsInLayout();
            Toast.makeText(getApplicationContext(), "Empty", Toast.LENGTH_SHORT).show();
        }

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }

    public interface FragmentChangeListener
    {
        public void replaceFragment(Fragment fragment);
    }

    private class FetchTotalViews extends AsyncTask<String, String, String> {

        @Override protected String doInBackground(String... params) {

            List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>();
            String[] POST_VALUES = { "department_id", "function" };
            for(int x = 0; x < params.length; x++) { nameValuePairs.add(new BasicNameValuePair(POST_VALUES[x], params[x])); }

            try {

                HttpClient httpClient = new DefaultHttpClient();
                HttpPost httpPost = new HttpPost("http://" + myServer.localhost() + "/eflier/api/eflier_api.php");
                httpPost.setEntity(new UrlEncodedFormEntity(nameValuePairs));
                HttpResponse httpResponse = httpClient.execute(httpPost);
                InputStream inputStream = httpResponse.getEntity().getContent();
                BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));
                StringBuilder sb = new StringBuilder(); String line = null;
                while((line = reader.readLine()) != null) { sb.append(line); }
                inputStream.close(); return sb.toString();
            }
            catch(Exception ex) { MessageBox("CONNECTION ERROR!"); }
            return null;
        }

        @Override protected void onPostExecute(String ResultSet) {

            try {

                JSONObject jsonObj = new JSONObject(ResultSet);
                JSONArray jsonArry = jsonObj.getJSONArray("Response");
                JSONObject jsonResultSet = jsonArry.getJSONObject(0);
                Integer isValid = jsonResultSet.getInt("isValid");

                if(isValid.equals(1)) {

                    AnalyticsNumber.setText(jsonResultSet.getString("num_of_views"));
                }
                else { MessageBox("ANALYTICS ERROR!"); }
            }
            catch(Exception ex) { MessageBox("JSON PARSING ERROR!"); }
        }
    }

    private class FetchDepartment extends AsyncTask<String, String, String> {

        @Override protected String doInBackground(String... params) {

            List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>();
            String[] POST_VALUES = { "department_id", "function" };
            for(int x = 0; x < params.length; x++) { nameValuePairs.add(new BasicNameValuePair(POST_VALUES[x], params[x])); }

            try {

                HttpClient httpClient = new DefaultHttpClient();
                HttpPost httpPost = new HttpPost("http://" + myServer.localhost() + "/eflier/api/department_api.php");
                httpPost.setEntity(new UrlEncodedFormEntity(nameValuePairs));
                HttpResponse httpResponse = httpClient.execute(httpPost);
                InputStream inputStream = httpResponse.getEntity().getContent();
                BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));
                StringBuilder sb = new StringBuilder(); String line = null;
                while((line = reader.readLine()) != null) { sb.append(line); }
                inputStream.close(); return sb.toString();
            }
            catch(Exception ex) { MessageBox("CONNECTION ERROR!"); }
            return null;
        }

        @Override protected void onPostExecute(String ResultSet) {

            try {

                JSONObject jsonObj = new JSONObject(ResultSet);
                JSONArray jsonArry = jsonObj.getJSONArray("Response");
                JSONObject jsonResultSet = jsonArry.getJSONObject(0);
                Integer isValid = jsonResultSet.getInt("isValid");

                if(isValid.equals(1)) {

                    myDepartment = new Department(jsonResultSet.getInt("DepartmentID"), jsonResultSet.getString("DepartmentName"), jsonResultSet.getString("Username"));
                    MessageBox("Welcome " + myDepartment.get_department_name() + "!");
                    new FetchTotalViews().execute(String.valueOf(myDepartment.get_department_id()), "FETCH_TOTAL_VIEWS");
                }
                else { MessageBox("DEPARTMENT DETAILS ERROR!"); }
            }
            catch(Exception ex) { MessageBox("JSON PARSING ERROR!"); }
        }
    }

    private void MessageBox(final String myMessage) {

        runOnUiThread(new Runnable() {

            @Override public void run() {

                Toast.makeText(getApplicationContext(), myMessage, Toast.LENGTH_SHORT).show();
            }
        });
    }

}
