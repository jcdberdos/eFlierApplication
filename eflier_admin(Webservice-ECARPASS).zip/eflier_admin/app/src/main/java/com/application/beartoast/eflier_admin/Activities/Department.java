package com.application.beartoast.eflier_admin.Activities;

/**
 * Created by JSabino on 2 Feb 2018.
 */

public class Department {
    private int _department_id = 0;
    private String _department_name = null;
    private String _username = null;

    public Department(int department_id, String department_name, String _username) {

        this._department_id = department_id;
        this._department_name = department_name;
        this._username = _username;
    }

    public int get_department_id()
    {
        return this._department_id;
    }

    public String get_department_name()
    {
        return this._department_name;
    }

    public String get_username()
    {
        return this._username;
    }
}
